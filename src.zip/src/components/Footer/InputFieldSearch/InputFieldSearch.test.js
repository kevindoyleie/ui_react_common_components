import React from 'react';
import InputFieldSearch from './InputFieldSearch';
import { footerContent, validators } from '../FooterData';
import { fireEvent, render, screen, within } from '@testing-library/react';
import { act } from 'react-dom/test-utils';

describe('Test component InputFieldSearch', () => {
  const testId = 'cmn-footer-search';

  beforeAll(() => {
    fakeCurrentUrl();
  });

  test('InputFieldSearch component exists', () => {
    render(<InputFieldSearch searchContent={footerContent.searchField} inputValidator={validators.isSearchTermValid} />);

    expect(screen.getByTestId(testId)).toBeInTheDocument();
  });

  test('Text input and submit buttons exist', () => {
    render(<InputFieldSearch searchContent={footerContent.searchField} inputValidator={validators.isSearchTermValid} />);
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));

    expect(getByPlaceholderText(footerContent.searchField.placeHolderText)).toBeInTheDocument();
    expect(getByTestId('cmn-footer-search-btn')).toBeInTheDocument();
  });

  test('Text input is empty, form submitted. Should stay on the same page.', async () => {
    render(<InputFieldSearch searchContent={footerContent.searchField} inputValidator={validators.isSearchTermValid} />);
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));
    const searchTerm = '';

    await act(async () => {
      fireEvent.input(getByPlaceholderText(footerContent.searchField.placeHolderText), { target: { value: searchTerm } });
      fireEvent.submit(getByTestId('cmn-footer-search-btn'));
    });

    expect(window.location.href).not.toContain(`/search?searchTerm=${searchTerm}`);
  });

  test('Text input is not empty, form submitted. Should redirect to /search page.', async () => {
    render(<InputFieldSearch searchContent={footerContent.searchField} inputValidator={validators.isSearchTermValid} />);
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));
    const searchTerm = 'searchText';

    await act(async () => {
      fireEvent.input(getByPlaceholderText(footerContent.searchField.placeHolderText), { target: { value: searchTerm } });
      fireEvent.submit(getByTestId('cmn-footer-search-btn'));
    });

    expect(window.location.href).toContain(`/search?searchTerm=${searchTerm}`);
  });

  function fakeCurrentUrl() {
    const currentLocation = new URL('http://localhost:3000/find-a-plan/start');
    delete window.location;
    window.location = currentLocation;
  }
});
