import React from 'react';
import Input from '../../Input/Input';
import Parser from 'html-react-parser';
import { useForm, FieldValues } from 'react-hook-form';
import { FooterType } from '../types';
import { InputType } from '../../Input/types';
import Styles from '../footer.module.scss';

function InputFieldSearch({ searchContent, inputValidator }: FooterType.IInputFieldSearchProps): JSX.Element {
  const inputClasses: InputType.IClasses = {
    inputClassName: Styles['search-input'],
  };

  const inputContent: InputType.IContent = {
    name: 'searchTerm',
    placeholder: searchContent.placeHolderText,
    errorMessage: searchContent.requiredMessage,
  };

  const {
    handleSubmit,
    register,
    formState: { errors },
  } = useForm();

  const onSubmit = (data: FieldValues) => {
    window.location.href = `${searchContent.action}?${inputContent.name}=${data[inputContent.name]}`;
  };

  return (
    <div className={Styles['search']} data-testid="cmn-footer-search">
      <form
        id="cmn-footer-search-form"
        role="search"
        action={searchContent.action}
        method="GET"
        onSubmit={handleSubmit(onSubmit)}
      >
        <Input
          dataTestId="cmn-footer-search-input"
          classes={inputClasses}
          content={inputContent}
          validation={{
            validator: inputValidator,
          }}
          register={register}
          errors={errors}
        />
        <button
          id="cmn-footer-search-btn"
          className={Styles['search-btn']}
          data-testid="cmn-footer-search-btn"
          type="submit"
        >
          {Parser(searchContent.buttonContent)}
        </button>
      </form>
    </div>
  );
}

export default InputFieldSearch;
