import React from 'react';
import { screen, render } from '@testing-library/react';
import Footer from './Footer';
import { footerContent, validators, onSubmitRetrieveQuote } from './FooterData';

describe('feature Footer', () => {
  test('Footer test', () => {
    render(<Footer footerContent={footerContent} validators={validators} onSubmitRetrieveQuote={onSubmitRetrieveQuote} />);
    expect(screen.getByTestId('cmn-footer')).toBeInTheDocument();
  });
});
