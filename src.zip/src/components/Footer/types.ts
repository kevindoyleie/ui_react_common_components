import { FieldValues, UseFormSetError } from 'react-hook-form';
import { InputType } from '../Input';

export namespace FooterType {
  export interface IBaseField {
    /** url */
    action: string;
    placeHolderText: string;
    /** '<p><img ></p>' */
    buttonContent: string;
    inputType: string;
  }

  export interface IRetrieveQuoteContent extends IBaseField {
    requiredMessage: string;
    inputName: string;
  }

  export interface IRetrieveQuoteField extends IRetrieveQuoteContent {
    ERROR_PAGE_404_URL: string;
  }

  export interface ILink {
    url: string;
    title: string;
    redirectUrl?: string;
  }

  export interface IHelpfulLinks {
    links: ILink[];
    helpfulLinksText: string;
  }

  export interface IAddressProps {
    addressContent: IAddressText;
  }

  export interface IConnectWithUsProps {
    connectWithUsContent: IConnectWithUs;
  }

  export interface IConnectWithUs {
    connectWithUsHeadingText: string;
    connectWithUsText: string;
  }

  export interface IContactUsProps {
    contactUsContent: IContactUsText;
  }

  export interface IHelpfulLinksProps {
    helpfulLinksContent: IHelpfulLinks;
  }

  export interface IInputFieldRetrieveQuoteProps {
    retrieveQuoteContent: IRetrieveQuoteContent;
    inputValidator: InputType.IValidator;
    onSubmit: OnSubmitType;
  }

  export interface ISearchContent {
    placeHolderText?: string;
    requiredMessage?: string;
    action: string;
    buttonContent: string;
  }

  export interface IInputFieldSearchProps {
    searchContent: ISearchContent;
    inputValidator: InputType.IValidator;
  }

  export interface IContent {
    helpfulLinks: IHelpfulLinks;
    retrieveQuoteField: IRetrieveQuoteField;
    searchField: IBaseField;
    contactUs: IContactUsText;
    address: IAddressText;
    addressContent: IAddressText;
    contactUsContent: IContactUsText;
    connectWithUs: IConnectWithUs;
  }

  export interface IAddressText {
    addressText: string;
  }

  export interface IContactUsText {
    contactUsText: string;
  }

  export interface IProps {
    footerContent: IContent;
    validators: IValidators;
    onSubmitRetrieveQuote: OnSubmitType;
  }

  export type OnSubmitType = (formData: FieldValues, setError: UseFormSetError<FieldValues>) => void;

  export interface IValidators {
    isQuoteRefValid: InputType.IValidator;
    isSearchTermValid: InputType.IValidator;
  }
}
