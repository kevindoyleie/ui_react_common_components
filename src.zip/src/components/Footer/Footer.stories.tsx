import React from 'react';
import Footer from './Footer';
import '../../styles/index.scss';
import { footerContent, validators, onSubmitRetrieveQuote } from './FooterData';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { FooterType } from './types';

export default {
  title: 'Layout/Footer',
  component: Footer,
} as ComponentMeta<typeof Footer>;

const Template: ComponentStory<typeof Footer> = (args: FooterType.IProps) => <Footer {...args} />;

export const Default = Template.bind({});

Default.args = {
  footerContent,
  validators,
  onSubmitRetrieveQuote,
};
