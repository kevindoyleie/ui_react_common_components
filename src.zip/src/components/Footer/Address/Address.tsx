import React from 'react';
import Parser from 'html-react-parser';
import { FooterType } from '../types';
import Styles from './address.module.scss';

function Address({ addressContent }: FooterType.IAddressProps): JSX.Element {
  return (
    <div className={Styles['footer__address']} data-testid="cmn-footer-address">
      {Parser(addressContent?.addressText)}
    </div>
  );
}

export default Address;
