import React from 'react';
import { screen, render } from '@testing-library/react';
import Address from './Address';
import { footerContent } from '../FooterData';

describe('feature Footer Address', () => {
  test('footer should always have Address', () => {
    const d = new Date();
    const year = d.getFullYear();
    const AddressContent = `Vhi Healthcare, IDA Business Park, Purcellsinch, Dublin Road, Kilkenny, Ireland. All rights reserved. All contents © ${year} Vhi Group`;

    render(<Address addressContent={footerContent.addressContent} />);

    expect(screen.getByTestId('cmn-footer-address')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-footer-address').textContent).toBe(AddressContent);
  });
});
