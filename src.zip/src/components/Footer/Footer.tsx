import React from 'react';
import Address from './Address/Address';
import ConnectWithUs from './ConnectWithUs/ConnectWithUs';
import ContactUs from './ContactUs/ContactUs';
import HelpfulLinks from './HelpfulLinks/HelpfulLinks';
import InputFieldRetrieveQuote from './InputFieldRetrieveQuote/InputFieldRetrieveQuote';
import InputFieldSearch from './InputFieldSearch/InputFieldSearch';
import { FooterType } from './types';
import Styles from './footer.module.scss';

/**
 * Responsive page footer component.
 *
 * Content is dynamic.
 */
function Footer({ footerContent, validators, onSubmitRetrieveQuote }: FooterType.IProps): JSX.Element {
  const { helpfulLinks, connectWithUs, retrieveQuoteField, searchField, contactUs, address } = footerContent || {};
  const { isQuoteRefValid, isSearchTermValid } = validators || {};

  return (
    <div className={Styles['footer']} data-testid="cmn-footer">
      <div className="container">
        <div className="row">
          <div className="col-12 col-lg-6">
            <HelpfulLinks helpfulLinksContent={helpfulLinks} />
          </div>
          <div className="col-12 col-lg-4">
            <div className={Styles['footer__connect-wrap']}>
              <ConnectWithUs connectWithUsContent={connectWithUs} />
              <InputFieldRetrieveQuote
                retrieveQuoteContent={retrieveQuoteField}
                inputValidator={isQuoteRefValid}
                onSubmit={onSubmitRetrieveQuote}
              />
              <InputFieldSearch searchContent={searchField} inputValidator={isSearchTermValid} />
            </div>
          </div>
          <div className="col-12 col-lg-2">
            <ContactUs contactUsContent={contactUs} />
          </div>
        </div>
        <div className="row">
          <Address addressContent={address} />
        </div>
      </div>
    </div>
  );
}

export default Footer;
