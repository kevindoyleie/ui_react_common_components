import React from 'react';
import Parser from 'html-react-parser';
import { FooterType } from '../types';
import Styles from './connectWithUs.module.scss';

function ConnectWithUs({ connectWithUsContent }: FooterType.IConnectWithUsProps): JSX.Element {
  return (
    <div
      id="cmn-footer__connect-with-us"
      className={Styles['footer__connect-with-us']}
      data-testid="cmn-footer-connect-with-us"
    >
      <div className={Styles['footer__connect-with-us__heading']} data-testid="cmn-footer-connect-with-us-heading">
        {Parser(connectWithUsContent.connectWithUsHeadingText)}
      </div>
      <div className={Styles['footer__connect-with-us__logos']} data-testid="cmn-footer-connect-with-us-logos">
        {Parser(connectWithUsContent.connectWithUsText)}
      </div>
    </div>
  );
}

export default ConnectWithUs;
