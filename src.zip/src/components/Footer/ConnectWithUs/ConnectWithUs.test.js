import React from 'react';
import { screen, render } from '@testing-library/react';
import ConnectWithUs from './ConnectWithUs';
import { footerContent } from '../FooterData';

describe('feature Footer Connect With Us', () => {
  test('footer should always have Connect With Us text and images', () => {
    render(<ConnectWithUs connectWithUsContent={footerContent.connectWithUs} />);
    expect(screen.getByTestId('cmn-footer-connect-with-us-heading').querySelector('p').textContent).toContain(
      'Connect With Us'
    );
    expect(screen.getAllByRole('link')).toHaveLength(2);
    expect(screen.getByTestId('cmn-footer-connect-with-us-logos').querySelector('p :nth-child(1)')).toHaveAttribute(
      'href',
      'https://www.facebook.com/VhiHealth/'
    );
    expect(screen.getByTestId('cmn-footer-connect-with-us-logos').querySelector('p :nth-child(1) img')).toHaveAttribute(
      'src',
      'https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/facebook-icon.png'
    );
    expect(screen.getByTestId('cmn-footer-connect-with-us-logos').querySelector('p :nth-child(2)')).toHaveAttribute(
      'href',
      'https://www.linkedin.com/company/vhi-healthcare'
    );
    expect(screen.getByTestId('cmn-footer-connect-with-us-logos').querySelector('p :nth-child(2) img')).toHaveAttribute(
      'src',
      'https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/linkedin-icon.png'
    );
  });
});
