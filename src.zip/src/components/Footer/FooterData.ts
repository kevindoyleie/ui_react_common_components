import { FooterType } from './types';

const footerContent: FooterType.IContent = {
  address: {
    addressText:
      '<p>Vhi Healthcare, IDA Business Park, Purcellsinch, Dublin Road, Kilkenny, Ireland. All rights reserved. All contents © 2022 Vhi Group</p>',
  },
  contactUs: {
    contactUsText:
      "<p>Contact Us</p><p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/phone-icon.png' alt=''>&nbsp;<a href='tel:0564444444'>056 444 4444</a></p>",
  },
  helpfulLinks: {
    links: [
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/vhi-spa-navigation/spa-footer-navigation/about-vhi.html',
        title: 'About Vhi Group',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/about-vhi',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/vhi-spa-navigation/spa-footer-navigation/downloads.html',
        title: 'Downloads',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/downloads',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/vhi-spa-navigation/spa-footer-navigation/about-recruitment.html',
        title: 'Careers',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/about/recruitment',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/vhi-spa-navigation/spa-footer-navigation/contact.html',
        title: 'Contact Us',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/contact',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/privacy-policy.html',
        title: 'Data Protection',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/vhi-spa-navigation/spa-footer-navigation/cookies.html',
        title: 'Cookie Information',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/cookies',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/accessibility.html',
        title: 'Accessibility',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/terms-of-use.html',
        title: 'Terms of Use',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/terms-of-business.html',
        title: 'Terms of Business',
      },
      {
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/fees-and-charges.html',
        title: 'Fees and Charges',
      },
    ],
    helpfulLinksText: '<p>Helpful Links</p>',
  },
  retrieveQuoteField: {
    ERROR_PAGE_404_URL: '/error-page-404',
    action: 'https://web-wam-05.vhihealthcare.net/products/retrievequote',
    placeHolderText: 'Retrieve a Quote',
    inputType: 'text',
    buttonContent: "<p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/go-icon.png' alt=''></p>",
    requiredMessage: "This quote reference can't be matched to a quote in our system.",
    inputName: 'quoteRef',
  },
  searchField: {
    action: 'https://web-wam-05.vhihealthcare.net/search',
    placeHolderText: 'Search',
    buttonContent: "<p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/search-icon.png' alt=''>&nbsp;</p>",
    inputType: 'text',
  },
  addressContent: {
    addressText:
      '<p>Vhi Healthcare, IDA Business Park, Purcellsinch, Dublin Road, Kilkenny, Ireland. All rights reserved. All contents © 2022 Vhi Group</p>',
  },
  contactUsContent: {
    contactUsText: `<p>Contact Us</p><p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/phone-icon.png' alt=''>&nbsp;<a href='tel:0564444444'>056 444 4444</a></p>`,
  },
  connectWithUs: {
    connectWithUsHeadingText: `<p>Connect With Us</p>`,
    connectWithUsText: `<p><a href='https://www.facebook.com/VhiHealth/'><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/facebook-icon.png' alt=''></a><a href='https://www.linkedin.com/company/vhi-healthcare'><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/linkedin-icon.png' alt=''></a></p>`,
  },
};

const validators: FooterType.IValidators = {
  isQuoteRefValid: (quoteRef) => {
    const pattern = /^$|^[0-9]+$/i;
    return pattern.test(quoteRef.toString());
  },
  isSearchTermValid: (searchTerm) => {
    return searchTerm.toString().trim().length > 0;
  },
};

const onSubmitRetrieveQuote: FooterType.OnSubmitType = (formData, setError) => {
  setError(footerContent.retrieveQuoteField.inputName, {});
};

export { footerContent, validators, onSubmitRetrieveQuote };
