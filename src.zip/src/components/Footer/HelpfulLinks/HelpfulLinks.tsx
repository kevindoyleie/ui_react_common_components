import React from 'react';
import Parser from 'html-react-parser';
import { FooterType } from '../types';
import Styles from './helpfulLinks.module.scss';

function HelpfulLinks({ helpfulLinksContent }: FooterType.IHelpfulLinksProps): JSX.Element {
  const { links, helpfulLinksText } = helpfulLinksContent || {};
  let footerLinks: FooterType.ILink[] = [];
  footerLinks = footerLinks.concat(links);

  const linkItems: JSX.Element[] = footerLinks.map((link, index) => {
    // build link id
    const linkId = `cmn-footer__helpful-links__link-${index}`;
    // build link class
    const classNameLeft = Styles['footer__helpful-links__link-left'];
    const classNameRight = Styles['footer__helpful-links__link-right'];
    // class - first 5 on left need different display property
    const classNameVal = index <= 4 ? classNameLeft : classNameRight;
    // build link href - some link to AEM, some to legacy depending on redirectUrl null or not
    const { redirectUrl, url, title } = link || {};
    const hrefVal = !redirectUrl ? url : redirectUrl;

    return (
      <a key={index} className={classNameVal} id={linkId} href={hrefVal}>
        {title}
      </a>
    );
  });

  return (
    <div className={Styles['footer__helpful-links']} data-testid="cmn-footer-helpful-links">
      <div className={Styles['footer__helpful-links__heading']}>{Parser(helpfulLinksText)}</div>
      <div className={Styles['footer__helpful-links__links']}>{linkItems}</div>
    </div>
  );
}

export default HelpfulLinks;
