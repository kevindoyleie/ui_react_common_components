import React from 'react';
import { screen, render } from '@testing-library/react';
import HelpfulLinks from './HelpfulLinks';
import { footerContent } from '../FooterData';

describe('feature HelpfulLinks', () => {
  test('footer should always have helpful links', () => {
    render(<HelpfulLinks helpfulLinksContent={footerContent.helpfulLinks} />);

    expect(screen.getByText('About Vhi Group').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-05.vhihealthcare.net/about-vhi'
    );

    expect(screen.getAllByRole('link')).toHaveLength(10);
  });

  test('Helpful Links url should use AEM url when redirect url is not found', () => {
    render(<HelpfulLinks helpfulLinksContent={footerContent.helpfulLinks} />);
    // Fees and Charges link in the test translation.json has had its redirectUrl removed for this test
    expect(screen.getByText('Fees and Charges').closest('a')).toHaveAttribute(
      'href',
      'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/fees-and-charges.html'
    );
  });

  test('footer should render when no Helpful Links returned from AEM', () => {
    footerContent.helpfulLinks.links = [];
    render(<HelpfulLinks helpfulLinksContent={footerContent.helpfulLinks} />);
    // even without the links in it (1st test), test that the component is still rendering ok (2nd test)
    expect(screen.queryAllByRole('link')).toHaveLength(0);
    expect(screen.getByTestId('cmn-footer-helpful-links').querySelector('div > p').textContent).toBe('Helpful Links');
  });
});
