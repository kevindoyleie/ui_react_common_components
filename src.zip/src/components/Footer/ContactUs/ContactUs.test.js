import React from 'react';
import { screen, render } from '@testing-library/react';
import ContactUs from './ContactUs';
import { footerContent } from '../FooterData';

describe('feature Footer Contact Us', () => {
  test('footer should always have Contact', () => {
    render(<ContactUs contactUsContent={footerContent.contactUsContent} />);
    expect(screen.getByTestId('cmn-footer-contact').getElementsByTagName('p')).toHaveLength(2);
    expect(screen.getByTestId('cmn-footer-contact').querySelector(':nth-child(2)').querySelector('img')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-footer-contact').querySelector(':nth-child(2)').querySelector('a')).toHaveAttribute(
      'href',
      'tel:0564444444'
    );
    expect(screen.getByTestId('cmn-footer-contact').querySelector('p').textContent).toBe('Contact Us');
  });
});
