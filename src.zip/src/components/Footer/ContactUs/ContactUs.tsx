import React from 'react';
import Parser from 'html-react-parser';
import { FooterType } from '../types';
import Styles from './contactUs.module.scss';

function ContactUs({ contactUsContent }: FooterType.IContactUsProps): JSX.Element {
  return (
    <div id="cmn-footer__contact" className={Styles['footer__contact']} data-testid="cmn-footer-contact">
      {Parser(contactUsContent.contactUsText)}
    </div>
  );
}

export default ContactUs;
