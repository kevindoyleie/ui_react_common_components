import React from 'react';
import { fireEvent, render, screen, within } from '@testing-library/react';
import InputFieldRetrieveQuote from './InputFieldRetrieveQuote';
import * as footerData from '../FooterData';
import { act } from 'react-dom/test-utils';

describe('Test component InputFieldRetrieveQuote', () => {
  const testId = 'cmn-footer-retrieve-quote';

  test('InputFieldRetrieveQuote component exists', async () => {
    render(
      <InputFieldRetrieveQuote
        retrieveQuoteContent={footerData.footerContent.retrieveQuoteField}
        inputValidator={footerData.validators.isQuoteRefValid}
        onSubmit={footerData.onSubmitRetrieveQuote}
      />
    );

    expect(screen.getByTestId(testId)).toBeInTheDocument();
  });

  test('Text input and submit buttons exist', async () => {
    render(
      <InputFieldRetrieveQuote
        retrieveQuoteContent={footerData.footerContent.retrieveQuoteField}
        inputValidator={footerData.validators.isQuoteRefValid}
        onSubmit={footerData.onSubmitRetrieveQuote}
      />
    );
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));

    expect(getByPlaceholderText(footerData.footerContent.retrieveQuoteField.placeHolderText)).toBeInTheDocument();
    expect(getByTestId('cmn-footer-retrieve-quote-btn')).toBeInTheDocument();
  });

  test('Input text is not valid, form submitted. Should display error message.', async () => {
    render(
      <InputFieldRetrieveQuote
        retrieveQuoteContent={footerData.footerContent.retrieveQuoteField}
        inputValidator={footerData.validators.isQuoteRefValid}
        onSubmit={footerData.onSubmitRetrieveQuote}
      />
    );
    const { getByTestId, getByPlaceholderText, getByText } = within(screen.getByTestId(testId));
    const quoteRef = 'abc';

    await act(async () => {
      fireEvent.input(getByPlaceholderText(footerData.footerContent.retrieveQuoteField.placeHolderText), {
        target: { value: quoteRef },
      });
      fireEvent.submit(getByTestId('cmn-footer-retrieve-quote-btn'));
    });

    expect(getByText(footerData.footerContent.retrieveQuoteField.requiredMessage)).toBeInTheDocument();
  });

  test('Text input is valid, form submitted. Should call onSubmitRetrieveQuote function', async () => {
    const onSubmitRetrieveQuoteSpy = jest.spyOn(footerData, 'onSubmitRetrieveQuote');

    render(
      <InputFieldRetrieveQuote
        retrieveQuoteContent={footerData.footerContent.retrieveQuoteField}
        inputValidator={footerData.validators.isQuoteRefValid}
        onSubmit={footerData.onSubmitRetrieveQuote}
      />
    );
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));
    const quoteRef = '12345';

    await act(async () => {
      fireEvent.input(getByPlaceholderText(footerData.footerContent.retrieveQuoteField.placeHolderText), {
        target: { value: quoteRef },
      });
      fireEvent.submit(getByTestId('cmn-footer-retrieve-quote-btn'));
    });

    expect.assertions(1);

    expect(onSubmitRetrieveQuoteSpy).toHaveBeenCalledTimes(1);
  });

  test('Text input is empty, form submitted. Should not call onSubmitRetrieveQuote function', async () => {
    const onSubmitRetrieveQuoteSpy = jest.spyOn(footerData, 'onSubmitRetrieveQuote');

    render(
      <InputFieldRetrieveQuote
        retrieveQuoteContent={footerData.footerContent.retrieveQuoteField}
        inputValidator={footerData.validators.isQuoteRefValid}
        onSubmit={footerData.onSubmitRetrieveQuote}
      />
    );
    const { getByTestId, getByPlaceholderText } = within(screen.getByTestId(testId));
    const quoteRef = '';

    await act(async () => {
      fireEvent.input(getByPlaceholderText(footerData.footerContent.retrieveQuoteField.placeHolderText), {
        target: { value: quoteRef },
      });
      fireEvent.submit(getByTestId('cmn-footer-retrieve-quote-btn'));
    });

    expect.assertions(1);

    expect(onSubmitRetrieveQuoteSpy).not.toHaveBeenCalled();
  });
});
