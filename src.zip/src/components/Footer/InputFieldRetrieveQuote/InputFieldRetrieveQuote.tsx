import React from 'react';
import Parser from 'html-react-parser';
import { useForm } from 'react-hook-form';
import Input from '../../Input/Input';
import { FooterType } from '../types';
import Styles from '../footer.module.scss';

function InputFieldRetrieveQuote({
  retrieveQuoteContent,
  inputValidator,
  onSubmit,
}: FooterType.IInputFieldRetrieveQuoteProps): JSX.Element {
  const inputClasses = {
    inputClassName: Styles['retrieve-quote-input'],
    errorMessageClassName: Styles['retrieve-quote-error-message'],
  };

  const inputContent = {
    name: retrieveQuoteContent.inputName,
    placeholder: retrieveQuoteContent.placeHolderText,
    errorMessage: retrieveQuoteContent.requiredMessage,
  };

  const {
    handleSubmit,
    register,
    setError,
    formState: { errors },
  } = useForm();

  return (
    <div className={Styles['retrieve-quote']} data-testid="cmn-footer-retrieve-quote">
      <form
        id="cmn-footer-retrieve-quote-form"
        action={retrieveQuoteContent.action}
        method="GET"
        onSubmit={handleSubmit((data) => {
          if (data.quoteRef) {
            onSubmit(data, setError);
          }
        })}
      >
        <Input
          dataTestId="cmn-footer-retrieve-quote-input"
          classes={inputClasses}
          content={inputContent}
          validation={{
            validator: inputValidator,
          }}
          register={register}
          errors={errors}
        />
        <button
          id="cmn-footer-retrieve-quote-btn"
          className={Styles['retrieve-quote-btn']}
          data-testid="cmn-footer-retrieve-quote-btn"
          type="submit"
        >
          {Parser(retrieveQuoteContent.buttonContent)}
        </button>
      </form>
    </div>
  );
}

export default InputFieldRetrieveQuote;
