import { screen, render } from '@testing-library/react';
import React from 'react';
import HeaderMenu from './HeaderMenu';
import headerContent from '../HeaderData';

describe('HeaderMenu component', () => {
  let env = {};

  test('data-testid exist', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByTestId('cmn-hdr-menu-Health')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Travel')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Dental')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Life')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Find-Care')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Claims')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Members')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Employers')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-Blog')).toBeInTheDocument();
  });

  test('menu links exist', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getAllByRole('link')).toHaveLength(11);
  });

  test('Health link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Health').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-05.vhihealthcare.net/health-insurance'
    );
  });

  test('Travel link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Travel').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-05.vhihealthcare.net/travel-insurance'
    );
  });

  test('Dental link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Dental').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-05.vhihealthcare.net/dental-insurance'
    );
  });

  test('Life link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Life').closest('a')).toHaveAttribute('href', 'https://web-wam-05.vhihealthcare.net/life');
  });

  test('Find Care link', () => {
    env.AEM_SERVER_PREFIX = 'https://vmsys166.vhihealthcare.net';
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Find Care').closest('a')).toHaveAttribute(
      'href',
      'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/360health.html'
    );
  });

  test('Claims link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Claims').closest('a')).toHaveAttribute('href', 'https://web-wam-05.vhihealthcare.net/claims');
  });

  test('Members link', () => {
    env.AEM_SERVER_PREFIX = 'https://vmsys166.vhihealthcare.net';
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Members').closest('a')).toHaveAttribute(
      'href',
      'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/members.html'
    );
  });

  test('Employers link', () => {
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Employers').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-05.vhihealthcare.net/employers'
    );
  });

  test('Blog link', () => {
    env.AEM_SERVER_PREFIX = 'https://vmsys166.vhihealthcare.net';
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('Blog').closest('a')).toHaveAttribute(
      'href',
      'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/blog.html'
    );
  });

  test('Header should render when no nav menu items returned from AEM', () => {
    // temporarily remove the list from the test data file
    //translation[':items'].header[':items'].redirect_navigation.items = [];
    headerContent.headerMenu.redirectItems = [];
    render(<HeaderMenu headerContent={headerContent} headerType="header-desktop" />);
    // even without the links in it (1st test), test that the component is still rendering ok (2nd test)
    // Note - the 2 represents the 2 phone number links.
    expect(screen.queryAllByRole('link')).toHaveLength(2);
  });
});
