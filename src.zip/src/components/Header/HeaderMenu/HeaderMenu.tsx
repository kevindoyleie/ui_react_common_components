import React from 'react';
import HeaderPhoneNumbers from '../HeaderPhoneNumbers/HeaderPhoneNumbers';
import { HeaderType } from '../types';
import Styles from '../header.module.scss';

function HeaderMenu({ headerContent, headerType }: HeaderType.IMenuProps): JSX.Element {
  const menuLinks = headerContent.headerMenu.redirectItems;
  const menuItems = menuLinks.map((link, index: number) => (
    <li
      data-testid={'cmn-hdr-menu-' + link.title.replace(/ /g, '-')}
      key={index}
      className={Styles['navbar__desktop-menu__navbar-li']}
    >
      <a href={!link.redirectUrl ? link.url : link.redirectUrl}>{link.title}</a>
    </li>
  ));

  return (
    <ul className="nav navbar-nav">
      <li className={Styles['navbar__mobile-menu__container']}>
        <div className={`${Styles['navbar__collapsed-phones']} d-flex d-lg-none`}>
          <div className={Styles['navbar__collapsed-phones__numbers']}>
            <HeaderPhoneNumbers headerContent={headerContent} headerType={headerType} />
          </div>
        </div>
      </li>
      {menuItems}
    </ul>
  );
}

export default HeaderMenu;
