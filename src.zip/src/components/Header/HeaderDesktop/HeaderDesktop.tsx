import React from 'react';
import { Navbar, Container } from 'react-bootstrap';
import HeaderTop from '../HeaderTop/HeaderTop';
import HeaderMenu from '../HeaderMenu/HeaderMenu';
import { HeaderType } from '../types';
import Styles from '../header.module.scss';

function HeaderDesktop({ headerContent }: HeaderType.IDesktopProps): JSX.Element {
  return (
    <Navbar
      data-testid="cmn-hdr-navbar"
      fixed="top"
      role="navigation"
      className={`${Styles['navbar--default']} d-none d-lg-block`}
    >
      <Container>
        <HeaderTop headerContent={headerContent} headerType="header-desktop1" />
      </Container>
      <div data-testid="cmn-hdr-menu" className={Styles['navbar__desktop-menu']}>
        <Container>
          <HeaderMenu headerContent={headerContent} headerType="header-desktop2" />
        </Container>
      </div>
    </Navbar>
  );
}

export default HeaderDesktop;
