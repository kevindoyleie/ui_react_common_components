import { screen, render, queryByAttribute } from '@testing-library/react';
import React from 'react';
import HeaderDesktop from './HeaderDesktop';
import headerContent from '../HeaderData';

describe('HeaderDesktop component', () => {
  test('data-testid DIVs exists', () => {
    render(<HeaderDesktop headerContent={headerContent} />);

    expect(screen.getByTestId('cmn-hdr-navbar')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu')).toBeInTheDocument();
  });
});
