export namespace HeaderType {
  export interface IRedirectItem {
    children: JSX.Element[];
    url?: string;
    redirectUrl?: string;
    title: string;
    description?: string;
  }

  interface IContentTop {
    AEM_SERVER_PREFIX: string;
    LEGACY_SERVER_PREFIX: string;
    link: string;
    alt: string;
    src: string;
    myVhiBtnText: string;
    loginRegBtnText: string;
  }

  export interface IContent {
    headerTop: IContentTop;
    headerMenu: {
      redirectItems: IRedirectItem[];
    };
    headerPhoneNumbers: {
      telIconText: string;
      telRefText: string;
    };
  }

  export interface IProps {
    headerContent: IContent;
  }

  export interface IDesktopProps {
    headerContent: IContent;
  }

  export interface IMobileProps {
    headerContent: IContent;
  }

  export interface IMenuProps {
    headerContent: IContent;
    headerType: string;
  }

  export interface IPhoneNumbersProps {
    headerContent: IContent;
    headerType: string;
  }

  export interface ITopProps {
    headerContent: IContent;
    headerType: string;
  }
}
