import React from 'react';
import Parser from 'html-react-parser';
import { HeaderType } from '../types';

function HeaderPhoneNumbers({ headerContent, headerType }: HeaderType.IPhoneNumbersProps): JSX.Element {
  const {
    headerPhoneNumbers: { telIconText, telRefText },
  } = headerContent;

  return (
    <>
      <div data-testid={`cmn-hdr-phone-local-${headerType}`}>{Parser(telIconText)}</div>
      {telRefText && (
        <>
          <div className="separator"></div>
          <div data-testid={`cmn-hdr-phone-1800-${headerType}`}>{Parser(telRefText)}</div>
        </>
      )}
    </>
  );
}

export default HeaderPhoneNumbers;
