import { screen, render } from '@testing-library/react';
import React from 'react';
import HeaderPhoneNumbers from './HeaderPhoneNumbers';
import headerContent from '../HeaderData';

describe('HeaderPhones component', () => {
  test('data-testids exist', () => {
    render(<HeaderPhoneNumbers headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByTestId('cmn-hdr-phone-local-header-desktop')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-phone-1800-header-desktop')).toBeInTheDocument();
  });

  test('check phone number content from AEM', () => {
    render(<HeaderPhoneNumbers headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('056 775 3003')).toBeInTheDocument();
    expect(screen.getByText('056 775 3003').closest('a')).toHaveAttribute('href', 'tel:0567753003');
    expect(screen.getByText('1800 211 558')).toBeInTheDocument();
    expect(screen.getByText('1800 211 558').closest('a')).toHaveAttribute('href', 'tel:1800211558');
  });
});
