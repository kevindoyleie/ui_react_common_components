import React from 'react';
import Header from './Header';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import headerContent from './HeaderData';
import { HeaderType } from './types';

export default {
  title: 'Layout/Header',
  component: Header,
} as ComponentMeta<typeof Header>;

const Template: ComponentStory<typeof Header> = (args: HeaderType.IProps) => <Header {...args} />;

export const Default = Template.bind({});
Default.args = {
  headerContent,
};
