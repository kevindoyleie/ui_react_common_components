import React, { useState } from 'react';
import { NavLink } from 'react-bootstrap';
import Parser from 'html-react-parser';
import HeaderPhoneNumbers from '../HeaderPhoneNumbers/HeaderPhoneNumbers';
import { HeaderType } from '../types';
import Styles from '../header.module.scss';

function HeaderTop({ headerContent, headerType }: HeaderType.ITopProps): JSX.Element {
  const [isShown, setIsShown] = useState(false);
  const { headerTop } = headerContent;

  return (
    <div data-testid="cmn-hdr-top" className={Styles['navbar__header']}>
      <NavLink
        id="cmn-hdr-top-logo"
        data-testid="cmn-hdr-top-logo"
        className={Styles['navbar__header__logo']}
        href={headerTop.link}
      >
        <img
          alt={headerTop.alt}
          src={headerTop.AEM_SERVER_PREFIX + headerTop.src}
          className={Styles['navbar__header__logo__img']}
        />
      </NavLink>
      <div className={Styles['navbar__navbar-phones']}>
        <HeaderPhoneNumbers headerContent={headerContent} headerType={headerType} />
      </div>
      <div className={Styles['navbar__header__navbar-myvhi']}>
        <div className={Styles['navbar__header__myvhi-wrapper']}>
          <a
            id="cmn-hdr-top-myvhi-btn"
            data-testid="cmn-hdr-top-myvhi-btn"
            href={headerTop.LEGACY_SERVER_PREFIX + '/myvhi'}
            className={Styles['navbar__header__navbar-myvhi__btn']}
            onMouseEnter={() => setIsShown(true)}
            onMouseLeave={() => setIsShown(false)}
          >
            {!isShown && (
              <div className={Styles['navbar__header__navbar-myvhi__btn__myvhi-text']}>{Parser(headerTop.myVhiBtnText)}</div>
            )}
            {isShown && (
              <div className={Styles['navbar__header__navbar-myvhi__btn__login-text']}>
                {Parser(headerTop.loginRegBtnText)}
              </div>
            )}
          </a>
        </div>
      </div>
    </div>
  );
}

export default HeaderTop;
