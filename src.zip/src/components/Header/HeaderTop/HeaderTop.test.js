import { screen, render, fireEvent } from '@testing-library/react';
import React from 'react';
import HeaderTop from './HeaderTop';
import headerContent from '../HeaderData';

describe('HeaderTop component', () => {
  let env = {};

  test('data-testids exist', () => {
    render(<HeaderTop headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByTestId('cmn-hdr-top')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-logo')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-myvhi-btn')).toBeInTheDocument();
  });

  test('check button labels from AEM', () => {
    headerContent.headerTop.LEGACY_SERVER_PREFIX = 'https://web-wam-53.vhihealthcare.net';

    render(<HeaderTop headerContent={headerContent} headerType="header-desktop" />);

    expect(screen.getByText('MyVhi')).toBeInTheDocument();
    expect(screen.getByText('MyVhi').closest('a')).toHaveAttribute('href', 'https://web-wam-53.vhihealthcare.net/myvhi');
  });

  test('check button when hover over button', () => {
    headerContent.headerTop.LEGACY_SERVER_PREFIX = 'https://web-wam-53.vhihealthcare.net';

    render(<HeaderTop headerContent={headerContent} headerType="header-desktop" />);
    fireEvent.mouseEnter(screen.getByTestId('cmn-hdr-top-myvhi-btn'));

    expect(screen.getByText('Log in/Register')).toBeInTheDocument();
    expect(screen.getByText('Log in/Register').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-53.vhihealthcare.net/myvhi'
    );
  });
});
