import React from 'react';
import HeaderDesktop from './HeaderDesktop/HeaderDesktop';
import HeaderMobile from './HeaderMobile/HeaderMobile';
import { HeaderType } from './types';

/**
 * Responsive page header component.
 *
 * Content is dynamic.
 */
function Header({ headerContent }: HeaderType.IProps): JSX.Element {
  return (
    <div data-testid="cmn-hdr">
      <HeaderDesktop headerContent={headerContent} />
      <HeaderMobile headerContent={headerContent} />
    </div>
  );
}

export default Header;
