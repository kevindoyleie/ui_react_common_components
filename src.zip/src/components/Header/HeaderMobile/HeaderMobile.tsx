import React, { useState } from 'react';
import { Navbar, NavLink, Container, CloseButton } from 'react-bootstrap';
import Parser from 'html-react-parser';
import HeaderMenu from '../HeaderMenu/HeaderMenu';
import { HeaderType } from '../types';
import Styles from '../header.module.scss';

function HeaderMobile({ headerContent }: HeaderType.IMobileProps): JSX.Element {
  const headerMobile = headerContent.headerTop;
  const [showMyVhiDropdown, setShowMyVhiDropdown] = useState(false);

  return (
    <Navbar
      data-testid="cmn-hdr-navbar-mobile"
      className={`${Styles['navbar--default']} d-flex d-lg-none`}
      fixed="top"
      expand="xs"
      variant="dark"
    >
      <Container>
        <Navbar.Toggle
          id="cmn-hdr-burger"
          aria-controls="responsive-navbar-nav"
          className="x"
          data-testid="cmn-hdr-burger"
          onClick={() => setShowMyVhiDropdown(false)}
        >
          <span className="navbar-toggler__icon-bar"></span>
          <span className="navbar-toggler__icon-bar"></span>
          <span className="navbar-toggler__icon-bar"></span>
        </Navbar.Toggle>
        <div data-testid="cmn-hdr-top-mob" className={Styles['navbar__header']}>
          <NavLink data-testid="cmn-hdr-top-logo-mob" className={Styles['navbar__header__logo']} href={headerMobile.link}>
            <img
              alt={headerMobile.alt}
              src={headerMobile.AEM_SERVER_PREFIX + headerMobile.src}
              className={Styles['navbar__header__logo__img']}
            />
          </NavLink>
          <div className={`${Styles['navbar__header__navbar-myvhi-mobile']} d-block d-lg-none`}>
            <NavLink
              id="cmn-hdr-top-myvhi-link-mob"
              data-testid="cmn-hdr-top-myvhi-link-mob"
              onClick={() => setShowMyVhiDropdown(true)}
              className={Styles['navbar__header__navbar-myvhi-mobile__btn']}
            >
              <span className={Styles['navbar__header__navbar-myvhi-mobile__btn__myvhi-text']}>
                {Parser(headerMobile.myVhiBtnText)}
              </span>
            </NavLink>
          </div>
        </div>
      </Container>
      <Navbar.Collapse id="responsive-navbar-nav" data-testid="cmn-hdr-menu-mobile">
        {/* Investigate if this is impacting the Container - bg does not exist on Container */}
        {/* <Container className="cmn-hdr__navbar__mobile-menu" bg="white"> */}
        <Container className={Styles['navbar__mobile-menu']}>
          <HeaderMenu headerContent={headerContent} headerType="header-mobile" />
        </Container>
      </Navbar.Collapse>
      {showMyVhiDropdown && (
        <div id="navbar-myvhi-dropdown" data-testid="navbar-myvhi-dropdown" className={Styles['navbar__myvhi-dropdown']}>
          <NavLink
            id="cmn-hdr-dropdown-myvhi-link"
            data-testid="cmn-hdr-dropdown-myvhi-link"
            href={headerMobile.LEGACY_SERVER_PREFIX + '/myvhi'}
            className={Styles['navbar__myvhi-dropdown__myvhi-btn']}
          >
            <span className={Styles['navbar__myvhi-dropdown__myvhi-btn__myvhi-text']}>
              {Parser(headerMobile.loginRegBtnText)}
            </span>
          </NavLink>
          <CloseButton
            data-testid="cmn-hdr-dropdown-close"
            className={Styles['navbar__myvhi-dropdown__close']}
            onClick={() => setShowMyVhiDropdown(false)}
          />
        </div>
      )}
    </Navbar>
  );
}

export default HeaderMobile;
