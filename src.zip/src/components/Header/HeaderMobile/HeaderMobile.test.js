import { screen, render, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import HeaderMobile from './HeaderMobile';
import headerContent from '../HeaderData';

describe('HeaderMobile component', () => {
  let env = {};

  test('data-testids exist', () => {
    render(<HeaderMobile headerContent={headerContent} />);

    expect(screen.getByTestId('cmn-hdr-navbar-mobile')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-burger')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-logo-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-myvhi-link-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-mobile')).toBeInTheDocument();
  });

  test('when click on burger toggle', async () => {
    render(<HeaderMobile headerContent={headerContent} />);

    expect(screen.getByTestId('cmn-hdr-burger')).toHaveClass('collapsed');

    fireEvent.click(screen.getByTestId('cmn-hdr-burger'));

    await waitFor(() => {
      expect(screen.getByTestId('cmn-hdr-burger')).not.toHaveClass('collapsed');
      expect(screen.getByTestId('cmn-hdr-menu-mobile')).toHaveClass('show');
    });
  });

  test('when click on MyVhi button the dropdown panel appears with another MyVhi button', () => {
    headerContent.headerTop.LEGACY_SERVER_PREFIX = 'https://web-wam-53.vhihealthcare.net';

    render(<HeaderMobile headerContent={headerContent} />);

    fireEvent.click(screen.getByText('MyVhi'));

    expect(screen.getByTestId('navbar-myvhi-dropdown')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-dropdown-myvhi-link')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-dropdown-close')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-dropdown-myvhi-link').closest('a')).toHaveAttribute(
      'href',
      'https://web-wam-53.vhihealthcare.net/myvhi'
    );
  });

  test('when click on close button in dropdown', () => {
    render(<HeaderMobile headerContent={headerContent} />);

    // Open the drop down
    fireEvent.click(screen.getByText('MyVhi'));
    // Close it
    fireEvent.click(screen.getByTestId('cmn-hdr-dropdown-close'));

    expect(screen.queryByTestId('navbar-myvhi-dropdown')).not.toBeInTheDocument();
  });
});
