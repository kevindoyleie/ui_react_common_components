import { HeaderType } from './types';

const headerContent: HeaderType.IContent = {
  headerTop: {
    AEM_SERVER_PREFIX: 'https://vmsys166.vhihealthcare.net',
    LEGACY_SERVER_PREFIX: 'https://web-wam-05.vhihealthcare.net',
    link: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en.html',
    alt: 'logo',
    src: '/content/vhi-spa/find-a-plan/_jcr_content/header/image.coreimg.png/1650968003167/vhi-header-logo.png',
    myVhiBtnText: '<p>MyVhi</p>',
    loginRegBtnText: '<p>Log in/Register</p>',
  },
  headerMenu: {
    redirectItems: [
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/health.html',
        title: 'Health',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/health-insurance',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/travel.html',
        title: 'Travel',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/travel-insurance',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/dental.html',
        title: 'Dental',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/dental-insurance',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/life.html',
        title: 'Life',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/life',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/360health.html',
        description:
          'Vhi 360 Health Centre provides Vhi members with rapid access to urgent care for minor injury and illness. Learn more about our services.\r\n',
        title: 'Find Care',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/claims.html',
        title: 'Claims',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/claims',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/members.html',
        title: 'Members',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/employers.html',
        title: 'Employers',
        redirectUrl: 'https://web-wam-05.vhihealthcare.net/employers',
      },
      {
        children: [],
        url: 'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/blog.html',
        title: 'Blog',
      },
    ],
  },
  headerPhoneNumbers: {
    telIconText: `<p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/phone-icon.png' alt=''>&nbsp;&nbsp;<a href='tel:0567753003'>056 775 3003</a></p>`,
    telRefText: `<p><a href='tel:1800211558'>1800 211 558</a></p>`,
  },
};

export default headerContent;
