import { screen, render, queryByAttribute } from '@testing-library/react';
import React from 'react';
import Header from './Header';
import headerContent from './HeaderData';

describe('Header component', () => {
  test('data-testids exist', () => {
    render(<Header headerContent={headerContent} />);
    expect(screen.getByTestId('cmn-hdr')).toBeInTheDocument();
  });

  test('Header contains all expected mobile data-testids', () => {
    const header = render(<Header headerContent={headerContent} />);
    const getById = queryByAttribute.bind(null, 'id');

    expect(screen.getByTestId('cmn-hdr-navbar-mobile')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-burger')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-logo-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-top-myvhi-link-mob')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-hdr-menu-mobile')).toBeInTheDocument();

    expect(getById(header.container, 'responsive-navbar-nav')).toBeInTheDocument();
    expect(getById(header.container, 'responsive-navbar-nav')).toHaveClass('collapse');
  });
});
