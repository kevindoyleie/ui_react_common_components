import React from 'react';
import Carousel from './Carousel';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { items, config, modulesConfig, navigationContent, customClasses, onSlideChange, setActiveSlideIndex } from './CarouselData';

export default {
  title: 'Miscellaneous/Carousel',
  component: Carousel,
} as ComponentMeta<typeof Carousel>;

const Template: ComponentStory<typeof Carousel> = (args) => {
  return <Carousel {...args} />;
};

export const Default = Template.bind({});
Default.args = {
  items: items,
  config: config,
  modulesConfig: modulesConfig,
  navigationContent: navigationContent,
  customClasses: customClasses,
  onSlideChange: onSlideChange,
  setActiveSlideIndex: setActiveSlideIndex
};  
