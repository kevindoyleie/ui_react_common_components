import { ReactNode } from 'react';
import { SwiperProps } from 'swiper/react';

export namespace CarouselType {
  export interface IConfig {
    className?: string;
    slidesPerView: number;
    spaceBetween: number;
    centeredSlides: boolean;
    autoHeight: boolean;
  }

  export type ItemType = ReactNode;
    export interface IProps {
      items: ItemType[];
      config: SwiperProps;
      modulesConfig: {
        isPagination: boolean;
        isNavigation: boolean;
        navigationThreshold?: number;
        nextSlideRange?: number;
        prevSlideRange?: number;
      };
      navigationContent?: {
        nextIcon?: string;
        previousIcon?: string;
      };
      customClasses?: {
        customNavigationWrapper?: string;
        customBtnNext?: string;
        customBtnPrev?: string;
      };
      onSlideChange?: () => void;
      setActiveSlideIndex?: (index: number) => void;
    }
  }
