import React from 'react';
import { Pagination, Navigation } from 'swiper';
import Parser from 'html-react-parser';
import { Swiper, SwiperSlide } from 'swiper/react';
import Styles from './carousel.module.scss';
import { CarouselType } from './types';
import { SwiperModule } from 'swiper/types';

/**
 * The Carousel component is used to display a given number of contents(text or image)
 * in a form of carousel/slider, allowing a user switch between items
 * either by sliding or clicking on pips.
 *
 * Content and configuration are dynamic.
 */

const defaultModulesConfig = {
  isPagination: false,
  isNavigation: false,
};

function Carousel({
  items,
  config,
  modulesConfig = defaultModulesConfig,
  navigationContent = {},
  customClasses = {},
  onSlideChange,
  setActiveSlideIndex,
}: CarouselType.IProps): JSX.Element {
  const { className } = config;
  const { customBtnNext, customBtnPrev, customNavigationWrapper } = customClasses;
  const { nextIcon, previousIcon } = navigationContent;
  const { isNavigation, isPagination, navigationThreshold, nextSlideRange, prevSlideRange } = modulesConfig;
  const _config = className ? config : { ...config, className: Styles.carousel };
  const btnNextCss = `${customBtnNext ?? Styles['swiper-button-next-position']}`;
  const btnPrevCss = `${customBtnPrev ?? Styles['swiper-button-prev-position']}`;
  const navWrapperCss = `${customNavigationWrapper ?? Styles['swiper-nav-wrapper']}`;

  const swiperButtonHide = `${Styles['swiper-button-hide']}`;

  const modules: SwiperModule[] = [];
  const [swiper, setSwiper] = React.useState<any>(null);
  const [activeIndex, setActiveIndex] = React.useState(0);

  const navigation = isNavigation && navigationThreshold && items.length > navigationThreshold;

  if (isPagination) {
    modules.push(Pagination);
  }

  if (navigation) {
    modules.push(Navigation);
  }

  const slideNext = () => {
    const nextSlide = nextSlideRange && swiper?.slideTo(swiper?.activeIndex + nextSlideRange);
    return nextSlide;
  };

  const slidePrev = () => {
    const prevSlide = prevSlideRange && swiper?.slideTo(swiper?.activeIndex - prevSlideRange);
    return prevSlide;
  };

  const slideChange = (index: number) => {
    setActiveIndex(index);
    if (typeof onSlideChange == 'function') {
      onSlideChange();
    }

    if (typeof setActiveSlideIndex == 'function') {
      setActiveSlideIndex(index);
    }
  };

  const baseSwiper = (
    <Swiper
      className="mySwiper"
      modules={modules}
      pagination={{ clickable: true }}
      onSwiper={(swiper) => setSwiper(swiper)}
      onSlideChange={(swiper) => slideChange(swiper.activeIndex)}
      {..._config}
    >
      {' '}
      {items.map((item, index) => (
        <SwiperSlide key={index}>{item}</SwiperSlide>
      ))}
    </Swiper>
  );

  if (!navigation) {
    return baseSwiper;
  }

  return (
    <div className={navWrapperCss}>
      <div className={`${btnNextCss} ${activeIndex === 0 ? swiperButtonHide : ''}`} onClick={slidePrev}>
        {Parser(previousIcon ?? '')}
      </div>
      {baseSwiper}
      <div className={`${btnPrevCss} ${swiper && swiper.isEnd ? swiperButtonHide : ''}`} onClick={slideNext}>
        {Parser(nextIcon ?? '')}
      </div>
    </div>
  );
}

export default Carousel;
