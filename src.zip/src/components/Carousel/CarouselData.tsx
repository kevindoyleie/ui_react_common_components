import React from 'react';
import { CarouselType } from './types';

const items: CarouselType.ItemType[] = [1, 2, 3, 4, 5].map((item) => {
  return (
    <div key={item} style={{ height: '400px', width: '200px', border: '1px solid black' }}>
      Item {item}
    </div>
  );
});

const config: CarouselType.IConfig = {
  className: undefined,
  slidesPerView: 3,
  spaceBetween: 0,
  centeredSlides: false,
  autoHeight: true,
};

const navigationContent = {
  previousIcon: `<p><img src='https://aem-int.vhihealthcare.net/content/dam/vhi-spa/icon-chevron-left.svg' alt='' /> </p>`,
  nextIcon: `<p><img src='https://aem-int.vhihealthcare.net/content/dam/vhi-spa/icon-chevron-right.svg' alt='' /> </p>`,
};

const customClasses = {

};

const modulesConfig = {
  isPagination: true,
  isNavigation: true,
  navigationThreshold: 3,
  nextSlideRange: 1,
  prevSlideRange: 3,
};

const setActiveSlideIndex = (index: number)=> {
  console.log('VALUE SET', index);
}

const onSlideChange = ()=> {
  console.log('slide change');
} 

export { items, config, modulesConfig, navigationContent, customClasses, onSlideChange, setActiveSlideIndex };
