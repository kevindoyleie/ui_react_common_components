import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import stepBuilder from './stepBuilder';
import Wizard from '../Wizard.container';

const STEP_ONE = 'stepOne';
const STEP_TWO = 'stepTwo';
const STEP_THREE = 'stepThree';
const STEP_FOUR = 'stepFour';
const baseTestId = 'baseTestId';

const URL_ONE = `/${STEP_ONE}`;
const URL_TWO = `/${STEP_TWO}`;
const URL_THREE = `/${STEP_THREE}`;
const URL_FOUR = `/${STEP_FOUR}`;

const EDITING = 'editing';
const COMPLETED_INACTIVE = 'completed-inactive';
const COMPLETED_ACTIVE = 'completed-active';
const UNTOUCHED = 'untouched';
const EDIT_MOVED_OFF = 'edit-moved-off';

const COMPLETE = 'complete';
const LEFT_SEGMENT = '.left';
const RIGHT_SEGMENT = '.right';

describe('Wizard', () => {
  describe('Labels', () => {
    test('Uses correct labels', () => {
      const current_path = URL_ONE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(false).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(false).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      expect(screen.getByLabelText(STEP_ONE)).toHaveTextContent(STEP_ONE);
      expect(screen.getByLabelText(STEP_TWO)).toHaveTextContent(STEP_TWO);
      expect(screen.getByLabelText(STEP_THREE)).toHaveTextContent(STEP_THREE);
      expect(screen.getByLabelText(STEP_FOUR)).toHaveTextContent(STEP_FOUR);
    });
  });

  describe('Step States', () => {
    test('On Step 3 shows Step 3 is Editing', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      expect(screen.getByLabelText(STEP_THREE)).toHaveClass(EDITING);
      expect(screen.getByTestId(`${baseTestId}-${STEP_THREE}`)).toHaveClass(EDITING);
    });

    test('On Step 3 shows Step 1 and 2 as being completed and inactive and Step 4 as Untouched', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      expect(screen.getByLabelText(STEP_ONE)).toHaveClass(COMPLETED_INACTIVE);
      expect(screen.getByTestId(`${baseTestId}-${STEP_ONE}`)).toHaveClass(COMPLETED_INACTIVE);

      expect(screen.getByLabelText(STEP_TWO)).toHaveClass(COMPLETED_INACTIVE);
      expect(screen.getByTestId(`${baseTestId}-${STEP_TWO}`)).toHaveClass(COMPLETED_INACTIVE);

      expect(screen.getByLabelText(STEP_THREE)).toHaveClass(EDITING);
      expect(screen.getByTestId(`${baseTestId}-${STEP_THREE}`)).toHaveClass(EDITING);

      expect(screen.getByLabelText(STEP_FOUR)).toHaveClass(UNTOUCHED);
      expect(screen.getByTestId(`${baseTestId}-${STEP_FOUR}`)).toHaveClass(UNTOUCHED);
    });

    test('On return to Step 2 after starting to edit but not completing Step 3', () => {
      const current_path = URL_TWO;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      expect(screen.getByLabelText(STEP_ONE)).toHaveClass(COMPLETED_INACTIVE);
      expect(screen.getByTestId(`${baseTestId}-${STEP_ONE}`)).toHaveClass(COMPLETED_INACTIVE);

      expect(screen.getByLabelText(STEP_TWO)).toHaveClass(COMPLETED_ACTIVE);
      expect(screen.getByTestId(`${baseTestId}-${STEP_TWO}`)).toHaveClass(COMPLETED_ACTIVE);

      expect(screen.getByLabelText(STEP_THREE)).toHaveClass(EDIT_MOVED_OFF);
      expect(screen.getByTestId(`${baseTestId}-${STEP_THREE}`)).toHaveClass(EDIT_MOVED_OFF);

      expect(screen.getByLabelText(STEP_FOUR)).toHaveClass(UNTOUCHED);
      expect(screen.getByTestId(`${baseTestId}-${STEP_FOUR}`)).toHaveClass(UNTOUCHED);
    });
  });

  describe('Line Segments', () => {
    test('When on Step 3, with steps 1 and 2 complete, will show correct line segments in step 1', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepOneDiv = screen.getByTestId(`${baseTestId}-${STEP_ONE}`);
      const rightSegment = stepOneDiv.querySelector(RIGHT_SEGMENT);

      expect(rightSegment).toHaveClass(COMPLETE);
    });

    test('when on Step 3, with steps 1 and 2 complete, will show correct line segments in step 2', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepTwoDiv = screen.getByTestId(`${baseTestId}-${STEP_TWO}`);
      const leftSegment = stepTwoDiv.querySelector(LEFT_SEGMENT);
      const rightSegment = stepTwoDiv.querySelector(RIGHT_SEGMENT);

      expect(leftSegment).toHaveClass(COMPLETE);
      expect(rightSegment).toHaveClass(COMPLETE);
    });

    test('When on Step 3, with steps 1 and 2 complete, will show correct line segments in step 3', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepThreeDiv = screen.getByTestId(`${baseTestId}-${STEP_THREE}`);
      const leftSegment = stepThreeDiv.querySelector(LEFT_SEGMENT);
      const rightSegment = stepThreeDiv.querySelector(RIGHT_SEGMENT);

      expect(leftSegment).toHaveClass(COMPLETE);
      expect(rightSegment).not.toHaveClass(COMPLETE);
    });

    test('when on Step 3, with steps 1 and 2 complete, will show correct line segment in step 4', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepFourDiv = screen.getByTestId(`${baseTestId}-${STEP_FOUR}`);
      const leftSegment = stepFourDiv.querySelector(LEFT_SEGMENT);

      expect(leftSegment).not.toHaveClass(COMPLETE);
    });

    test('When Editing Step 4, with steps 1, 2, 3 complete, will show correct line segment in step 4', () => {
      const current_path = URL_FOUR;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepFourDiv = screen.getByTestId(`${baseTestId}-${STEP_FOUR}`);
      const leftSegment = stepFourDiv.querySelector(LEFT_SEGMENT);

      expect(screen.getByLabelText(STEP_FOUR)).toHaveClass(EDITING);
      expect(leftSegment).not.toHaveClass(COMPLETE);
    });
  });

  describe('First and Last Steps line segment', () => {
    test('Step 1 line has no left segment', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepOneDiv = screen.getByTestId(`${baseTestId}-${STEP_ONE}`);
      const leftSegment = stepOneDiv.querySelector(LEFT_SEGMENT);

      expect(leftSegment).toBe(null);
    });

    test('Step 4 line has no right segment', () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepFourDiv = screen.getByTestId(`${baseTestId}-${STEP_FOUR}`);
      const rightSegment = stepFourDiv.querySelector(RIGHT_SEGMENT);

      expect(rightSegment).toBe(null);
    });
  });

  describe('Navigation', () => {
    test('On Step 3 user is able to go back to step 1', async () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepOne = screen.getByLabelText(STEP_ONE);

      await userEvent.click(stepOne);
      await expect(navigate).toBeCalledWith(URL_ONE);
    });

    test('On Step 3 user is able to go back to step 2', async () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepTwo = screen.getByLabelText(STEP_TWO);

      await userEvent.click(stepTwo);
      await expect(navigate).toBeCalledWith(URL_TWO);
    });

    test('On Step 3 user is not able to go to step 4', async () => {
      const current_path = URL_THREE;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepFour = screen.getByLabelText(STEP_FOUR);

      await userEvent.click(stepFour);
      await expect(navigate).not.toBeCalled();
    });

    test('On going back to Step 2 from Step 3, is able to go forward to Step 3', async () => {
      const current_path = URL_TWO;

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(null).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(null).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(null).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(null).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepThree = screen.getByLabelText(STEP_THREE);

      await userEvent.click(stepThree);
      await expect(navigate).toBeCalledWith(URL_THREE);
    });
  });

  describe('Invoking Callback function', () => {
    test('On Step 3 user clicking Step 1 invokes Step 1 callback', async () => {
      const current_path = URL_THREE;

      const callBackOne = jest.fn();
      const callBackTwo = jest.fn();
      const callBackThree = jest.fn();
      const callBackFour = jest.fn();

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(callBackOne).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(callBackTwo).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(callBackThree).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(callBackFour).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepOne = screen.getByLabelText(STEP_ONE);

      await userEvent.click(stepOne);
      await expect(callBackOne).toBeCalled();

      await expect(callBackTwo).not.toBeCalled();
      await expect(callBackThree).not.toBeCalled();
      await expect(callBackFour).not.toBeCalled();
    });

    test('On Step 3 user clicking Step 2 invokes Step 2 callback', async () => {
      const current_path = URL_THREE;

      const callBackOne = jest.fn();
      const callBackTwo = jest.fn();
      const callBackThree = jest.fn();
      const callBackFour = jest.fn();

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(callBackOne).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(callBackTwo).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(callBackThree).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(callBackFour).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepTwo = screen.getByLabelText(STEP_TWO);

      await userEvent.click(stepTwo);
      await expect(callBackTwo).toBeCalled();

      await expect(callBackOne).not.toBeCalled();
      await expect(callBackThree).not.toBeCalled();
      await expect(callBackFour).not.toBeCalled();
    });

    test('On Step 3 user clicking Step 3 does not invoke Step 3 callback', async () => {
      const current_path = URL_THREE;

      const callBackOne = jest.fn();
      const callBackTwo = jest.fn();
      const callBackThree = jest.fn();
      const callBackFour = jest.fn();

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(callBackOne).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(callBackTwo).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(callBackThree).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(callBackFour).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepThree = screen.getByLabelText(STEP_THREE);

      await userEvent.click(stepThree);

      await expect(callBackOne).not.toBeCalled();
      await expect(callBackTwo).not.toBeCalled();
      await expect(callBackThree).not.toBeCalled();
      await expect(callBackFour).not.toBeCalled();
    });

    test('On Step 3 user clicking Step 4 does not invoke Step 4 callback', async () => {
      const current_path = URL_THREE;

      const callBackOne = jest.fn();
      const callBackTwo = jest.fn();
      const callBackThree = jest.fn();
      const callBackFour = jest.fn();

      const steps = [
        new stepBuilder().withLabel(STEP_ONE).withIsComplete(true).withOnClick(callBackOne).withUrl(URL_ONE).build(),
        new stepBuilder().withLabel(STEP_TWO).withIsComplete(true).withOnClick(callBackTwo).withUrl(URL_TWO).build(),
        new stepBuilder().withLabel(STEP_THREE).withIsComplete(false).withOnClick(callBackThree).withUrl(URL_THREE).build(),
        new stepBuilder().withLabel(STEP_FOUR).withIsComplete(false).withOnClick(callBackFour).withUrl(URL_FOUR).build(),
      ];
      const useMatch = jest.fn().mockImplementation((path) => path === current_path);
      const navigate = jest.fn();

      const props = { steps, useMatch, navigate, baseTestId };
      render(<Wizard {...props} />);

      const stepFour = screen.getByLabelText(STEP_FOUR);

      await userEvent.click(stepFour);

      await expect(callBackOne).not.toBeCalled();
      await expect(callBackTwo).not.toBeCalled();
      await expect(callBackThree).not.toBeCalled();
      await expect(callBackFour).not.toBeCalled();
    });
  });
});
