function StepBuilder() {
  const step = {};

  this.withLabel = (label) => {
    step.label = label;
    return this;
  };

  this.withUrl = (url) => {
    step.url = url;
    return this;
  };

  this.withOnClick = (onClick) => {
    step.onClick = onClick;
    return this;
  };

  this.withIsComplete = (isComplete) => {
    step.isComplete = isComplete;
    return this;
  };

  this.build = () => step;

  return this;
}

export default StepBuilder;
