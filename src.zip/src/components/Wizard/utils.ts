import { WizardType } from './types';

const getStepState = (isComplete: boolean, isActive: boolean, isEditMovedOff: boolean | undefined) => {
  if (isComplete && isActive) {
    return WizardType.StepStates.COMPLETED_ACTIVE;
  }
  if (isComplete && !isActive) {
    return WizardType.StepStates.COMPLETED_INACTIVE;
  }
  if (!isComplete && isActive) {
    return WizardType.StepStates.EDITING;
  }
  if (!isComplete && !isActive && !isEditMovedOff) {
    return WizardType.StepStates.UNTOUCHED;
  }
  if (isEditMovedOff) {
    return WizardType.StepStates.EDIT_MOVED_OFF;
  }
};

export const setFlags = (steps: WizardType.IViewStep[]) => {
  const activeStep = steps.find((step: WizardType.IViewStep) => step.isActive);

  const activeIsComplete = activeStep && activeStep.isComplete;
  const indexOfFirstIncomplete = steps.findIndex((step: WizardType.IViewStep) => !step.isComplete);

  return steps.map((step: WizardType.IViewStep, index: number) => {
    const { isComplete, isActive } = step;
    const isEditMovedOff = activeIsComplete && index === indexOfFirstIncomplete;
    const state = getStepState(isComplete, isActive, isEditMovedOff);
    return { ...step, state };
  });
};
