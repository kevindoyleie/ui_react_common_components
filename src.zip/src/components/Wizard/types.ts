import { MouseEventHandler } from 'react';

export namespace WizardType {
  export enum StepStates {
    COMPLETED_INACTIVE = 'completed-inactive',
    COMPLETED_ACTIVE = 'completed-active',
    EDITING = 'editing',
    EDIT_MOVED_OFF = 'edit-moved-off',
    UNTOUCHED = 'untouched',
  }

  export interface IContainerStep {
    label: string;
    isComplete: boolean;
    url: string;
  }

  export interface IViewStep extends IContainerStep {
    isFirst: boolean;
    isLast: boolean;
    isActive: boolean;
    previousComplete: boolean | null;
    state?: StepStates | undefined;
    onClick?: StepClickType;
  }

  export type StepClickType = ((stepClick: IStepClick) => void) | null;

  export interface IBaseProps {
    navigate: () => unknown;
    genericContainerCss: string;
    stepContainerCss: string;
    stepCss: string;
    lineCss: string;
    baseTestId: string;
  }

  export interface IStepClick {
    label: string;
    isComplete: boolean;
    state?: string | undefined;
  }

  export interface IStepProps {
    baseTestId: string;
    isComplete: boolean;
    isFirst: boolean;
    isLast: boolean;
    label: string;
    lineCss: string;
    navigate: (route: string) => void;
    onClick?: StepClickType;
    previousComplete: boolean | null;
    state?: string | undefined;
    stepContainerCss: string;
    stepCss: string;
    url: string;
  }

  export interface IStepViewProps {
    handleClick: MouseEventHandler<HTMLDivElement> | null;
    isFirst: boolean;
    isLast: boolean;
    label: string;
    leftCss: string;
    rightCss: string;
    state: string;
    stepContainerCss: string;
    stepCss: string;
    testId: string;
  }

  export interface IContainerProps extends IBaseProps {
    steps: IContainerStep[];
    useMatch: (url: string) => unknown;
  }

  export interface IViewProps extends IBaseProps {
    steps: IViewStep[];
  }
}
