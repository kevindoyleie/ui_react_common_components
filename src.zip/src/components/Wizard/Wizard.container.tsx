import React from 'react';
import View from './Wizard.view';
import { setFlags } from './utils';
import { WizardType } from './types';

const Wizard = ({ steps: inputSteps, useMatch, ...props }: WizardType.IContainerProps): JSX.Element => {
  const augmentSteps = (steps: WizardType.IContainerStep[]) => {
    const _steps: WizardType.IViewStep[] = [];
    const lastIndex = steps.length - 1;
    for (let i = 0; i <= lastIndex; i++) {
      const { url } = steps[i];
      _steps.push({
        ...steps[i],
        isFirst: i === 0,
        isLast: i === lastIndex,
        isActive: !!useMatch(url),
        previousComplete: i > 0 ? steps[i - 1].isComplete : null,
      });
    }
    return setFlags(_steps);
  };

  const steps = augmentSteps(inputSteps);

  return <View steps={steps} {...props} />;
};

export default Wizard;
