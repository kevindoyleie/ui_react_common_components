import React from 'react';
import Step from './Step/Step.container';
import Styles from './wizard.module.scss';
import { WizardType } from './types';

const WizardView = ({ steps, genericContainerCss = Styles.container, ...props }: WizardType.IViewProps): JSX.Element => (
  <div className={genericContainerCss}>
    {steps.map((step) => (
      <Step key={`step-${step.label}`} {...step} {...props} />
    ))}
  </div>
);

export default WizardView;
