import React from 'react';
import Styles from '../wizard.module.scss';
import View from './Step.view';
import { WizardType } from '../types';

const Step = ({
  label,
  isComplete,
  url,
  onClick,
  previousComplete,
  state,
  lineCss = Styles.line,
  baseTestId,
  navigate,
  ...props
}: WizardType.IStepProps): JSX.Element => {
  const testId = `${baseTestId}-${label}`;

  const showLink = state === WizardType.StepStates.COMPLETED_INACTIVE || state === WizardType.StepStates.EDIT_MOVED_OFF;

  const handler = () => {
    if (onClick) {
      onClick({ label, isComplete, state });
    }

    if (url) {
      navigate(url);
    }
  };

  const handleClick = showLink ? handler : null;

  const leftCss = `${lineCss} ${Styles.left} ${previousComplete ? Styles.complete : ''}`;
  const rightCss = `${lineCss} ${Styles.right} ${isComplete ? Styles.complete : ''}`;

  const viewProps = { label, state: state ?? '', handleClick, leftCss, rightCss, testId };

  return <View {...viewProps} {...props} />;
};

export default Step;
