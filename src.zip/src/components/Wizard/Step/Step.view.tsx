import React from 'react';
import Styles from '../wizard.module.scss';
import { WizardType } from '../types';

const StepView = ({
  label,
  state,
  handleClick,
  isFirst,
  isLast,
  stepContainerCss = Styles['step-container'],
  stepCss = Styles.step,
  leftCss,
  rightCss,
  testId,
}: WizardType.IStepViewProps): JSX.Element => (
  <div className={`${stepContainerCss} ${Styles[state]}`} data-testid={testId}>
    <div className={`${stepCss} ${Styles[state]}`} {...(handleClick && { onClick: handleClick })} aria-label={label}>
      {label}
    </div>

    {!isFirst && <div className={leftCss} />}

    {!isLast && <div className={rightCss} />}
  </div>
);

export default StepView;
