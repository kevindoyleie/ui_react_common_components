import { CtaButtonType } from './types';

export const content: CtaButtonType.IContent = {
  title: 'Next',
  name: 'Next',
};

export const onClickFunction: CtaButtonType.AlertType = () => {
  alert('Test!');
};
