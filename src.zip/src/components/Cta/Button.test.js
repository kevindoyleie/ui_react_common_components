import React from 'react';
import { screen, render, within, fireEvent } from '@testing-library/react';
import Button from './Button';
import { content } from './ButtonData';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  register: jest.fn(),
}));

describe('Testing Button ', () => {
  test('should have label ', () => {
    render(
      <Button
        id="cmn-button-start-next"
        dataTestId="cmn-button-start-next"
        classes={{}}
        content={content}
        disabled={true}
        form={content.form}
        type={content.type}
      />
    );
    const { getByText } = within(screen.getByTestId('cmn-button-start-next'));
    expect(getByText('Next')).toBeInTheDocument();
  });

  test('should be clickable', () => {
    const handleClick = jest.fn();
    render(
      <Button
        id="cmn-button-start-next"
        dataTestId="cmn-button-start-next"
        classes={{}}
        content={content}
        form={content.form}
        type={content.type}
        handleClick={handleClick}
      />
    );

    fireEvent.click(screen.getByTestId('cmn-button-start-next'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
});
