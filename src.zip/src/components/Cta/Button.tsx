import React from 'react';
import { CtaButtonType } from './types';
import Styles from './button.module.scss';

const defaultSize = CtaButtonType.Size.Default;
const defaultColour = CtaButtonType.Colour.Orange;

/**
 * The button component is used to trigger an action.
 *
 * Styling, size and content are dynamic.
 */
const Button = ({
  id,
  dataTestId,
  classes = {},
  content,
  disabled,
  form,
  type = 'button',
  size = defaultSize,
  colour = defaultColour,
  transparent = false,
  handleClick,
}: CtaButtonType.IProps): JSX.Element => {
  let label;

  const { labelClassName = '', inputClassName = '' } = classes as CtaButtonType.IClasses;
  const labelColourCss = colour === defaultColour ? Styles['button__label'] : Styles[`button-${colour}__label`];
  const labelCss = `${labelColourCss} ${labelClassName}`;

  const suffix = transparent ? '-x' : '';
  const inputColourCss = colour === defaultColour ? Styles[`button${suffix}`] : Styles[`button-${colour}${suffix}`];
  const inputSizeCss = size === defaultSize ? '' : Styles[`button--${size}`];
  const transCss = transparent ? Styles['button'] : '';
  const inputCss = `${inputColourCss} ${inputSizeCss} ${inputClassName} ${transCss}`.trim();

  if (content.title) {
    label = <div className={labelCss}>{content.title}</div>;
  }

  return (
    <div data-testid={`${dataTestId}-wrap`} className={Styles['button-wrap']}>
      <button
        id={id}
        data-testid={dataTestId}
        name={content.name}
        onClick={handleClick}
        className={inputCss}
        disabled={disabled}
        form={form}
        type={type}
      >
        {label}
      </button>
    </div>
  );
};

export default Button;
