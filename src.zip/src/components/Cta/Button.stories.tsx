import React from 'react';
import Button from './Button';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import * as buttonData from './ButtonData';
import { CtaButtonType } from './types';

export default {
  title: 'Controls/Button',
  component: Button,
  argTypes: { handleClick: { action: 'clicked' } },
} as ComponentMeta<typeof Button>;

const Template: ComponentStory<typeof Button> = ({ ...args }) => {
  return <Button {...args} />;
};

export const ButtonDefault = Template.bind({});
ButtonDefault.args = {
  content: buttonData.content,
  dataTestId: 'test-id',
  form: 'form-id',
  type: 'submit',
  classes: {},
};

export const Large = Template.bind({});
Large.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Large,
};

export const LargeDisabled = Template.bind({});
LargeDisabled.args = {
  ...Large.args,
  size: CtaButtonType.Size.Large,
  disabled: true,
};

export const Medium = Template.bind({});
Medium.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Medium,
};

export const MediumPlus = Template.bind({});
MediumPlus.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.MediumPlus,
};

export const Small = Template.bind({});
Small.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Small,
};

export const ClickAction = Template.bind({});
ClickAction.args = {
  ...ButtonDefault.args,
  content: { title: 'Click Me', name: 'ClickMe' },
  size: CtaButtonType.Size.Large,
  handleClick: buttonData.onClickFunction,
};

export const LargeWhite = Template.bind({});
LargeWhite.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Large,
  colour: CtaButtonType.Colour.White,
};

export const LargeWhiteDisabled = Template.bind({});
LargeWhiteDisabled.args = {
  ...LargeWhite.args,
  disabled: true,
};

export const MediumWhite = Template.bind({});
MediumWhite.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Medium,
  colour: CtaButtonType.Colour.White,
};

export const MediumPlusWhite = Template.bind({});
MediumPlusWhite.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.MediumPlus,
  colour: CtaButtonType.Colour.White,
};

export const SmallWhite = Template.bind({});
SmallWhite.args = {
  ...ButtonDefault.args,
  size: CtaButtonType.Size.Small,
  colour: CtaButtonType.Colour.White,
};

export const ClickActionWhite = Template.bind({});
ClickActionWhite.args = {
  ...ClickAction.args,
  colour: CtaButtonType.Colour.White,
};
