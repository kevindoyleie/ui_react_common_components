import { MouseEventHandler } from 'react';

export namespace CtaButtonType {
  export interface IContent {
    title: string;
    name: string;
  }

  export interface IClasses {
    labelClassName?: string;
    inputClassName?: string;
  }

  export type AlertType = () => void;

  export interface IProps {
    id: string;
    dataTestId: string;
    classes?: IClasses;
    content: {
      name: string;
      title?: React.ReactNode;
    };
    disabled?: boolean;
    form?: string;
    type?: 'button' | 'submit' | 'reset';
    handleClick?: MouseEventHandler<HTMLButtonElement>;
    size?: Size;
    colour?: Colour;
    transparent?: boolean;
  }

  export enum Size {
    Small = 'sm',
    SmallPlus = 'sm-1',
    Medium = 'md',
    MediumPlus = 'md-1',
    Large = 'lg',
    Default = '',
  }

  export enum Colour {
    Orange = '',
    White = 'white',
  }
}
