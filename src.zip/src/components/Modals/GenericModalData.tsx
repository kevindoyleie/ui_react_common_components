import React, { useState } from 'react';
import { Button } from 'react-bootstrap';
import Styles from './genericModal.module.scss';
import { ModalType } from './types';
import { Accordion, ExpandAllButton } from '../Accordion';
import { data } from '../Accordion/AccordionData';

// The property "action" can't be optional because "handleAction" in GenericModal can't accept undefined
const modalCtas: ModalType.IFooterCTA[] = [
  {
    id: 'cta-yes',
    text: 'Yes',
    action: () => {
      // eslint-disable-next-line no-console
      console.log('Yes action');
    },
    ctaClassName: 'extra-cta-class-name-yes',
    style: { minWidth: '80px' },
  },
  {
    id: 'cta-no',
    text: 'No',
    style: { minWidth: '120px' },
  },
];

const content: ModalType.IContent = {
  modalContent: {
    xIcon: `<p><img src='https://aem-int.vhihealthcare.net/content/dam/vhi-spa/x-big.png' alt='' /> </p>`,
    warningIcon: `<p><img src='https://aem-int.vhihealthcare.net/content/dam/vhi-spa/warning-icon.png' alt='' /></p>`,
    modalHeading: `<p>Are you sure?</p>`,
    modalMainText: `<p>Are you sure you want to delete this person?</p>`,
    ctas: modalCtas,
  },
};

const customCTATestFunction = () => {
  // eslint-disable-next-line no-console
  console.log('test function output');
};

const customContent: ModalType.IContent = {
  modalContent: {
    customContent: {
      header: (
        <div className="hqe-benefit__benefit-card__cardiac-modal__header">
          <div className="hqe-benefit__benefit-card__cardiac-modal__title-icon">
            <p>
              <img src="https://aem-int.vhihealthcare.net/content/dam/vhi-spa/care-cardiac-grey-icon.svg" alt="" />{' '}
            </p>
          </div>
          <div>
            <p>CARDIAC</p>
          </div>
          <div>
            <p>You have chosen a level of Cardiac that is suitable for most people.</p>
          </div>
          <div>
            <p>
              <img src="https://aem-int.vhihealthcare.net/content/dam/vhi-spa/care-tick-icon.svg" alt="" />{' '}
            </p>
          </div>
        </div>
      ),
      body: (
        <div>
          <div className="hqe-benefit__benefit-card__cardiac-modal__body">
            <div className="hqe-benefit__benefit-card__cardiac-modal__body-icon">
              <p>
                <img src="https://aem-int.vhihealthcare.net/content/dam/vhi-spa/care-cardiac-plus-grey-icon.svg" alt="" />{' '}
              </p>
            </div>
            <div>
              <p>COMPLEX CARDIAC PROCEDURES</p>
            </div>
            <div>
              <p>
                Additional cover for specialised minimally invasive cardiac operations such as Aortic, Mitral and Pulmonary
                valve surgery and LAA Occlusion. Typically for patients that have undergone cardiac surgeries.
              </p>
              <p>Would you like to add Complex Cardiac Procedures?</p>
            </div>
            <div>
              <p>
                <img src="https://aem-int.vhihealthcare.net/content/dam/vhi-spa/care-tick-icon.svg" alt="" />{' '}
              </p>
            </div>
            <div className="test-custom-header">
              <Button
                className="hqe-benefit__benefit-card__cardiac-modal__body-cta"
                onClick={() => {
                  customCTATestFunction();
                }}
              >
                Add Benefit
              </Button>
            </div>
          </div>
        </div>
      ),
    },
    ctas: [
      {
        id: 'cta-continue',
        text: 'Continue',
        action: () => {
          // eslint-disable-next-line no-console
          console.log('Yes action');
        },
        ctaClassName: Styles['extra-cta-class-name'],
        style: { minWidth: '80px', backgroundColor: '#e17000' },
      },
    ],
  },
};

const AccordionContent = () => {
  const [expanded, setExpanded] = useState<number[]>([]);
  const [disabled, setDisabled] = useState<boolean>(false);

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'flex-end', width: '100%' }}>
        <ExpandAllButton
          setExpanded={setExpanded}
          setDisabled={setDisabled}
          allItems={data.map((i) => data.indexOf(i))}
          color="secondary"
        />
      </div>

      <Accordion items={data} expanded={expanded} setExpanded={setExpanded} disabled={disabled} />
    </>
  );
};

const accordionBody = {
  modalContent: {
    customContent: {
      header: <div />,
      body: <AccordionContent />,
    },
  },
};

const longTextContent = {
  modalContent: {
    customContent: {
      header: (
        <div>
          <span>Header</span>
        </div>
      ),
      body: (
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
          aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
          sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>
      ),
    },
  },
};

export { content, customContent, accordionBody, longTextContent };
