import React from 'react';
import { Button, Col, Container, Modal, Row } from 'react-bootstrap';
import Parser from 'html-react-parser';
import Styles from './genericModal.module.scss';
import ButtonStyles from '../Cta/button.module.scss';
import { ModalType } from './types';

/**
 * The GenericModal component is used to display a modal window to a user.
 *
 * Styling, number of buttons and content are dynamic.
 */
const GenericModal = ({
  size,
  dataTestId,
  content,
  showModal,
  setShowModal,
  classes = '',
  dialogClassName,
}: ModalType.IProps): JSX.Element => {
  const handleAction = (action: (() => void) | undefined) => {
    if (typeof action !== 'undefined') {
      action();
    }
    setShowModal(false);
  };

  const setOnHide = () => setShowModal(false);

  const CTA_CLASS = `${ButtonStyles['button']} ${ButtonStyles['button--md-1']}  ${ButtonStyles['button-modal']}`;

  const { warningIcon, modalHeading, customContent, modalMainText, ctas } = content.modalContent;

  return (
    <Modal
      size={size}
      id={dataTestId}
      data-testid={dataTestId}
      show={showModal}
      className={`${Styles['container']} ${classes}`}
      dialogClassName={dialogClassName}
      centered
      backdrop="static"
      keyboard={false}
      onHide={setOnHide}
    >
      <Modal.Header className="d-flex justify-content-center">
        {customContent?.header ? (
          customContent.header
        ) : (
          <Modal.Title>
            <Container>
              <Row>
                <Col className={`d-flex justify-content-center ${Styles['container__warningIcon']}`}>
                  <div data-testid={`${dataTestId}-warning-icon`}>{Parser(warningIcon as string)}</div>
                </Col>
              </Row>
              <Row>
                <Col className={`d-flex justify-content-center ${Styles['container__title']}`}>
                  <div data-testid={`${dataTestId}-modal-heading`}>{Parser(modalHeading as string)}</div>
                </Col>
              </Row>
            </Container>
          </Modal.Title>
        )}
      </Modal.Header>
      <Modal.Body>
        {customContent?.body ? (
          customContent.body
        ) : (
          <Container>
            <Row>
              <Col className={`d-flex justify-content-center ${Styles['container__body']}`}>
                <div data-testid={`${dataTestId}-modal-main-text`}>{Parser(modalMainText as string)}</div>
              </Col>
            </Row>
          </Container>
        )}
      </Modal.Body>
      <Modal.Footer className={`d-flex justify-content-center ${Styles['container__footer']}`}>
        {ctas &&
          ctas.map((cta: ModalType.IFooterCTA, i: number) => (
            <Button
              id={cta.id}
              data-testid={`${dataTestId}-${cta.id}`}
              className={`${CTA_CLASS} ${cta.ctaClassName ?? ''}`}
              key={i}
              onClick={() => {
                handleAction(cta.action);
              }}
              style={cta.style}
            >
              {cta.text}
            </Button>
          ))}
      </Modal.Footer>
    </Modal>
  );
};

export default GenericModal;
