export { default as GenericModal } from './GenericModal';
export * from './types';
