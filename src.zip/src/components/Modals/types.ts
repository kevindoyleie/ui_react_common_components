import React, { ReactNode } from 'react';

export namespace ModalType {
  export interface IProps {
    size?: 'sm' | 'lg' | 'xl';
    id?: string;
    dataTestId?: string;
    content: any;
    showModal: boolean;
    setShowModal: (arg: boolean) => void;
    classes?: string;
    dialogClassName?: string;
  }

  export interface IFooterCTA {
    id: string | undefined;
    ctaClassName?: string;
    action?: () => void;
    style?: React.CSSProperties | undefined;
    text?: ReactNode;
  }

  export interface IContent {
    modalContent: {
      xIcon?: string;
      warningIcon?: string;
      modalHeading?: string;
      modalMainText?: string;
      ctas?: IFooterCTA[];
      customContent?: {
        header?: ReactNode;
        body?: ReactNode;
        ctas?: IFooterCTA[];
      };
    };
  }
}
