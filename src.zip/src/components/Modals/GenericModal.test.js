import React from 'react';
import { screen, render, fireEvent } from '@testing-library/react';
import GenericModal from './GenericModal';
import { act } from 'react-dom/test-utils';
import { content, longTextContent } from './GenericModalData';

describe('Testing Generic Modal', () => {
  const testId = 'generic-modal-testid';

  test('Generic Modal NO elements render with show as false', () => {
    const showModal = false;
    const setShowModal = () => {};

    render(
      <GenericModal id={testId} dataTestId={testId} content={content} showModal={showModal} setShowModal={setShowModal} />
    );

    const modalContainerDiv = screen.queryByTestId(testId);
    expect(modalContainerDiv).toBeNull();
  });

  test('Generic Modal elements render', () => {
    const showModal = true;
    const setShowModal = () => {};

    render(
      <GenericModal id={testId} dataTestId={testId} content={content} showModal={showModal} setShowModal={setShowModal} />
    );

    expect(screen.queryByTestId(`${testId}-warning-icon`)).toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-modal-heading`)).toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-modal-main-text`)).toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-cta-yes`)).toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-cta-no`)).toBeInTheDocument();
    expect(screen.getByTestId('generic-modal-testid-cta-yes')).toHaveStyle(`min-width: 80px`);
    expect(screen.getByTestId('generic-modal-testid-cta-no')).toHaveStyle(`min-width: 120px`);
  });

  test('Generic Modal test null CTAs still allows Modal to render', () => {
    const showModal = true;
    const setShowModal = () => {};
    delete content.modalContent.ctas;
    const DIALOGUE_CLASSNAME = 'custom-dialogue-class-name';
    const CLASSES = 'extra-class-name';

    render(
      <GenericModal
        id={testId}
        dataTestId={testId}
        content={content}
        showModal={showModal}
        setShowModal={setShowModal}
        dialogClassName={DIALOGUE_CLASSNAME}
        classes={CLASSES}
      />
    );

    expect(screen.queryByTestId(testId)).toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-cta-yes`)).not.toBeInTheDocument();
    expect(screen.queryByTestId(`${testId}-cta-no`)).not.toBeInTheDocument();
    expect(screen.getByTestId(testId)).toHaveClass('custom-dialogue-class-name');
    expect(screen.getByRole('dialog')).toHaveClass('extra-class-name');
  });

  test('Generic Modal test CTA click events', async () => {
    const showModal = true;
    const setShowModal = () => {};

    const mockCTAYes = jest.fn();
    const mockCTANo = jest.fn();

    const modalCtas = [
      {
        id: 'cta-yes',
        text: 'Yes',
        action: mockCTAYes,
        ctaClassName: 'extra-cta-class-name-yes',
        style: { minWidth: '80px', backgroundColor: '#e17000' },
      },
      {
        id: 'cta-no',
        text: 'No',
        action: mockCTANo,
      },
    ];

    content.modalContent.ctas = modalCtas;

    render(
      <GenericModal id={testId} dataTestId={testId} content={content} showModal={showModal} setShowModal={setShowModal} />
    );

    await act(async () => {
      fireEvent.click(screen.getByTestId(`${testId}-cta-yes`));
    });

    expect(mockCTAYes).toHaveBeenCalledTimes(1);

    await act(async () => {
      fireEvent.click(screen.getByTestId(`${testId}-cta-no`));
    });

    expect(mockCTANo).toHaveBeenCalledTimes(1);
    expect(screen.getByTestId(`${testId}-cta-yes`)).toBeInTheDocument();
    expect(screen.getByTestId(`${testId}-cta-yes`)).toHaveClass('extra-cta-class-name-yes');
    // test that inline style background-color has overridden background-color from custom style
    expect(screen.getByTestId(`${testId}-cta-yes`)).toHaveStyle({ backgroundColor: '#e17000' });
  });

  test('Custom Modal elements render', () => {
    const showModal = true;
    const setShowModal = jest.fn();

    render(
      <GenericModal
        id={testId}
        dataTestId={testId}
        content={longTextContent}
        showModal={showModal}
        setShowModal={setShowModal}
      />
    );

    const childElement = screen.getByText('Lorem ipsum', { exact: false });
    expect(childElement).toBeInTheDocument();
  });
});
