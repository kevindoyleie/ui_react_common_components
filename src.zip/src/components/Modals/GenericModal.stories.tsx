import React, { useState } from 'react';
import GenericModal from './GenericModal';
import { content, customContent, accordionBody, longTextContent } from './GenericModalData';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { ModalType } from './types';

export default {
  title: 'Miscellaneous/GenericModal',
  component: GenericModal,
  parameters: {
    docs: {
      inlineStories: false,
    },
  },
} as ComponentMeta<typeof GenericModal>;

const testId = 'generic-modal-testid';

const Template: ComponentStory<typeof GenericModal> = (args: ModalType.IProps) => {
  // use parent's state to control Modal's show/hide
  /* set useState to 'false' before committing or tests will fail.
  Needs to be set to true to see the storybook */
  const [showModal, setShowModal] = useState(true);

  return (
    <GenericModal
      size={args.size}
      id={args.id}
      dataTestId={args.dataTestId}
      content={args.content}
      showModal={showModal}
      setShowModal={setShowModal}
      dialogClassName={args.dialogClassName}
      classes={args.classes}
    />
  );
};

export const Default = Template.bind({});
Default.args = {
  id: testId,
  dataTestId: testId,
  content: content,
  classes: 'extra-class-name',
};

export const WithCustomContent = Template.bind({});
WithCustomContent.args = {
  id: testId,
  dataTestId: testId,
  content: customContent,
  dialogClassName: 'custom-dialogue-class-name custom-dialogue-class-name-two',
  classes: 'extra-class-name',
};

export const AccordionBodyContent = Template.bind({});
AccordionBodyContent.args = {
  content: accordionBody,
};

export const LongTextCustomContent = Template.bind({});
LongTextCustomContent.args = {
  content: longTextContent,
};
