import { CustomDatePickerType } from './types';

const content: CustomDatePickerType.IContent = {
  title: 'Your policy will start on',
  name: 'policyStartDate',
  placeholder: 'DD/MM/YYYY',
  required: true,
  requiredMessage: 'Please select a date',
  errorMessage: 'Please select a date',
  imageContent:
    "<p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/calender-picker-icon.png' alt=''>&nbsp;</p>",
  policyStartDateInfoIcon:
    "<p><img src='https://aem-int.vhihealthcare.net/content/dam/vhi-spa/hospital-info-icon.svg' alt='' /> </p>",
  policyStartDateInfoText: '<p>You must choose a date within 30 days from today</p>',
};

const classes: CustomDatePickerType.IClasses = {};

const minStartDate = (days: number): number => {
  const date = new Date();
  return date.setDate(date.getDate() - days);
};

const maxStartDate = (days: number): number => {
  const date = new Date();
  return date.setDate(date.getDate() + days);
};

export { content, classes, minStartDate, maxStartDate };
