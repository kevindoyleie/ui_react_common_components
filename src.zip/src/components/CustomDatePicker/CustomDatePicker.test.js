import React from 'react';
import { screen, render, within } from '@testing-library/react';
import CustomDatePicker from './CustomDatePicker';
import { classesDefault, content, minStartDate, maxStartDate } from './CustomDatePickerData';
import { control } from 'react-hook-form';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  control: {},
  Controller: () => <></>,
}));

describe('Testing atomic component DatePicker', () => {
  test('should have label - Your policy will start on ', () => {
    render(
      <CustomDatePicker
        id="start-date-field"
        dataTestId="start-date-field"
        classes={classesDefault}
        content={content}
        control={control}
        minStartDate={minStartDate(0)}
        maxStartDate={maxStartDate(29)}
      />
    );
    const { getByText } = within(screen.getByTestId('start-date-field-wrap'));
    expect(getByText('Your policy will start on')).toBeInTheDocument();
  });
});
