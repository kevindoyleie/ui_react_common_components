import { FieldErrors } from 'react-hook-form/dist/types';
import { DropdownType } from '../Dropdown';

export namespace CustomDatePickerType {
  export interface IContent {
    title?: string;
    name: string;
    /** example "DD/MM/YYYY" */
    placeholder: string;
    required: boolean;
    requiredMessage: string;
    errorMessage: string;
    imageContent: string;
    policyStartDateInfoIcon: string;
    policyStartDateInfoText: string;
  }

  export enum Variant {
    small = 'sm',
    medium = 'md',
  }

  export interface IClasses {
    labelClassName?: string;
    calendarImageClassName?: string;
    inputClassName?: string;
    inputErrorClassName?: string;
    errorMessageClassName?: string;
  }

  export interface IProps {
    id?: string;
    dataTestId: string;
    classes?: IClasses;
    content: IContent;
    control: DropdownType.ControlType;
    minStartDate: Date | null | undefined;
    maxStartDate: Date | null | undefined;
    errors?: FieldErrors;
    variant?: Variant;
  }
}
