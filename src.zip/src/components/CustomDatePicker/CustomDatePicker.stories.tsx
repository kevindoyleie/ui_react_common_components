import React from 'react';

import { useForm } from 'react-hook-form';

import CustomDatePicker from './CustomDatePicker';
import { ComponentStory, ComponentMeta } from '@storybook/react';

import { classes, content, minStartDate, maxStartDate } from './CustomDatePickerData';

export default {
  title: 'Example/CustomDatePicker',
  component: CustomDatePicker,
} as ComponentMeta<typeof CustomDatePicker>;

const Template: ComponentStory<typeof CustomDatePicker> = () => {
  const { control } = useForm();

  return (
    <CustomDatePicker
      id="sb-date-picker-default"
      dataTestId="title-field"
      classes={classes}
      content={content}
      control={control}
      minStartDate={new Date(minStartDate(0))}
      maxStartDate={new Date(maxStartDate(29))}
      errors={{}}
    />
  );
};

export const Default = Template.bind({});
Default.args = {
  content,
  classes,
};
