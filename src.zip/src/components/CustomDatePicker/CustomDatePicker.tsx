import React from 'react';
import DatePicker from 'react-datepicker';
import { Controller } from 'react-hook-form';
import Parser from 'html-react-parser';
import Tooltip from '../Tooltip/Tooltip';
import Styles from './input.module.scss';
import { CustomDatePickerType } from './types';

/**
 * The custom date picker component is used to select a date from calendar.
 *
 *  Styling and content are dynamic. Min and max start dates are configurable.
 */
const CustomDatePicker = ({
  id,
  dataTestId,
  classes = {},
  content,
  control,
  minStartDate,
  maxStartDate,
  errors,
  variant = CustomDatePickerType.Variant.medium,
}: CustomDatePickerType.IProps): JSX.Element => {
  const { title, policyStartDateInfoText, policyStartDateInfoIcon, imageContent, placeholder, name, errorMessage } = content;

  const {
    labelClassName = Styles['input-field__label'],
    inputClassName = Styles['input-field'],
    errorMessageClassName = Styles['input-field__error-message'],
    calendarImageClassName = Styles['calendar-img'],
  } = classes;

  const variantCss = Styles[`input-field__${variant}`];

  return (
    <div data-testid={`${dataTestId}-wrap`}>
      <span className={Styles['input__label-wrap']}>
        {title && <p className={labelClassName}>{title}</p>}
        {policyStartDateInfoText && (
          <span className={Styles['input__date-picker-tooltip']}>
            <Tooltip
              id={`date-picker-start-date`}
              content={{
                moreInfoHover: {
                  hoverText: policyStartDateInfoText,
                },
                moreInfoMainTitleText: policyStartDateInfoIcon,
              }}
              classes={{
                tooltipClass: 'cmn-more-info-hover__tooltip',
                tooltipButtonClass: 'cmn-more-info-hover__button p-0',
              }}
              width="200px"
            />
          </span>
        )}
      </span>
      <div className={calendarImageClassName}>{Parser(imageContent)}</div>
      <Controller
        // TODO: Investigate type - there is no type prop in documentation
        // https://react-hook-form.com/api/usecontroller/controller/#main
        // type="date"
        control={control}
        name={name}
        render={({ field }) => (
          <DatePicker
            id={id}
            className={`${inputClassName} ${variantCss}`}
            selected={field.value ? field.value : new Date().getTime()}
            onChange={(val) => field.onChange(val)}
            minDate={minStartDate}
            maxDate={maxStartDate}
            placeholderText={placeholder}
            dateFormat="dd/MM/yyyy"
            formatWeekDay={(nameOfDay) => nameOfDay.substr(0, 1)}
            showMonthDropdown
            showYearDropdown
            dropdownMode="select"
          />
        )}
      />
      {errors?.[name] && <p className={errorMessageClassName}>{errorMessage}</p>}
    </div>
  );
};

export default CustomDatePicker;
