import React from 'react';
import Authorisation from './Authorisation';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import authorisationContent from './AuthorisationData';

export default {
  title: 'Roles/Authorisation',
  component: Authorisation,
} as ComponentMeta<typeof Authorisation>;

const Template: ComponentStory<typeof Authorisation> = (args) => <Authorisation {...args} />;

export const Default = Template.bind({});

Default.args = {
  authorisationContent,
};
