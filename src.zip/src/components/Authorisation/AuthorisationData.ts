import { AuthorisationType } from './types';

const authorisationContent: AuthorisationType.IContent = {
  authText: `<p><img src='https://vmsys166.vhihealthcare.net/content/dam/vhi-spa/vhi-disclaimer-logo.png' alt=''></p><p>Vhi Healthcare DAC trading as Vhi Healthcare is regulated by the Central Bank of Ireland.</p><p>Vhi Healthcare is tied to Vhi Insurance DAC for health insurance in Ireland which is underwritten by Vhi Insurance DAC.</p>`,
};

export default authorisationContent;
