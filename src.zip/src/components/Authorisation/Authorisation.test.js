import React from 'react';
import { screen, render } from '@testing-library/react';
import Authorisation from './Authorisation';
import authorisationContent from './AuthorisationData';

describe('feature Footer Authorisation', () => {
  test('footer should always have Authorisation', () => {
    const AuthorisationFirtParagraph =
      'Vhi Healthcare DAC trading as Vhi Healthcare is regulated by the Central Bank of Ireland.';
    const AuthorisationSecondParagraph =
      'Vhi Healthcare is tied to Vhi Insurance DAC for health insurance in Ireland which is underwritten by Vhi Insurance DAC.';

    render(<Authorisation authorisationContent={authorisationContent} />);

    expect(screen.getByTestId('cmn-authorisation').querySelector(':nth-child(2)').textContent).toBe(
      AuthorisationFirtParagraph
    );
    expect(screen.getByTestId('cmn-authorisation').querySelector(':nth-child(3)').textContent).toBe(
      AuthorisationSecondParagraph
    );

    // test that the main div has a <p> tag with a direct child that's an img element
    expect(screen.getByTestId('cmn-authorisation').querySelector('div > p > img')).toBeInTheDocument();
  });
});
