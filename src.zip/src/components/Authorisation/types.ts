export namespace AuthorisationType {
  export interface IContent {
    authText: string;
  }

  export interface IProps {
    authorisationContent: IContent;
  }
}
