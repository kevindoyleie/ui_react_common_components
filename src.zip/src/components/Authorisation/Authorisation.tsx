import React from 'react';
import Parser from 'html-react-parser';
import Styles from './authorisation.module.scss';
import { AuthorisationType } from './types';

/**
 * The footer authorisation component.
 *
 * Content is dynamic.
 */
function Authorisation({ authorisationContent }: AuthorisationType.IProps): JSX.Element {
  return (
    <div className={Styles.authorisation} data-testid="cmn-authorisation">
      {Parser(authorisationContent.authText)}
    </div>
  );
}

export default Authorisation;
