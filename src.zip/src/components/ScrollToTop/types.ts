export namespace ScrollToTopType {
  export interface IProps {
    useLocation: () => {
      pathname: string;
    };
  }
}
