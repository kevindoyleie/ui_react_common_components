import { useEffect } from 'react';
import { ScrollToTopType } from './types';

function ScrollToTop({ useLocation }: ScrollToTopType.IProps) {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);

  return null;
}

export default ScrollToTop;
