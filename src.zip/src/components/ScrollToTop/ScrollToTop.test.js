import React from 'react';
import { render } from '@testing-library/react';
import ScrollToTop from './ScrollToTop';

describe('ScrollToTop component tests', () => {
  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should invoke scrollTo', () => {
    const scrollToSpy = jest.spyOn(window, 'scrollTo');

    const useLocation = jest.fn();
    useLocation.mockReturnValueOnce({
      pathname: '/dummy',
    });

    render(<ScrollToTop useLocation={useLocation} />);

    expect(scrollToSpy).toBeCalled();
  });
});
