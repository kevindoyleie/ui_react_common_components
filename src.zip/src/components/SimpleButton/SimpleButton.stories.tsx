import React from 'react';
import SimpleButton from './SimpleButton';
import { ComponentStory, ComponentMeta } from '@storybook/react';

export default {
  title: 'Controls/SimpleButton',
  component: SimpleButton,
} as ComponentMeta<typeof SimpleButton>;

const Template: ComponentStory<typeof SimpleButton> = ({ ...args }) => {
  return <SimpleButton {...args}>Buy now</SimpleButton>;
};

export const Default = Template.bind({});

Default.argTypes = {
  variant: {
    control: { type: 'select' },
    options: ['primary', 'outline-primary', 'default', 'outline-secondary'],
  },
  size: {
    control: { type: 'select' },
    options: ['sm', 'md', 'lg'],
  },
};

Default.args = {
  variant: 'outline-primary',
  size: 'lg',
  disabled: false,
  id: 'test-id',
  dataTestId: 'datatest-id',
  handleClick: () => {
    alert('click');
  },
};
