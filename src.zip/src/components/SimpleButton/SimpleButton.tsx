import React from 'react';
import { Button as BootstrapButton } from 'react-bootstrap';
import { ButtonType } from './types';
import Styles from './button.module.scss';

/**
 * The button component is used to trigger an action.
 *
 * Styling, size and content are dynamic.
 */
function SimpleButton({
  children,
  id,
  dataTestId,
  handleClick,
  size,
  variant,
  type,
  disabled = false,
  fullWidth = false,
}: ButtonType.IProps) {
  const additionalClassNames = fullWidth ? 'full-width' : '';

  return (
    <div className={Styles.button}>
      <BootstrapButton
        id={id}
        datatest-id={dataTestId}
        onClick={handleClick}
        className={additionalClassNames}
        size={size}
        variant={variant}
        type={type}
        disabled={disabled}
      >
        {children}
      </BootstrapButton>
    </div>
  );
}

export default SimpleButton;
