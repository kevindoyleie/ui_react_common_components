import { ReactNode } from 'react';
import { ButtonProps } from 'react-bootstrap';

export namespace ButtonType {
  export interface IProps extends ButtonProps {
    children: ReactNode;
    fullWidth?: boolean;
    id?: string;
    dataTestId?: string;
    handleClick?: () => void;
  }
}
