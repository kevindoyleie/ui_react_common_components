import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import SimpleButton from './SimpleButton';

describe('Testing SimpleButton component', () => {
  const TEXT = 'test text';

  test('check if SimpleButton is rendered', async () => {
    render(<SimpleButton>{TEXT}</SimpleButton>);
    const button = screen.getAllByRole('button');

    expect(button[0]).toBeInTheDocument();
  });

  test('check if SimpleButton is clicked', async () => {
    const mockClick = jest.fn();

    render(<SimpleButton handleClick={mockClick}>{TEXT}</SimpleButton>);

    const button = screen.getAllByRole('button') as HTMLButtonElement[];

    fireEvent.click(button[0]);

    expect(mockClick).toHaveBeenCalled();
  });
});
