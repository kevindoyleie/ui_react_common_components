import { HTMLAttributes } from 'react';

export namespace TextType {
    type ColorType = 'grey-black' |
        'grey-dark' |
        'grey-darkest' |
        'grey-light' |
        'grey-lightest' |
        'primary-base' |
        'primary-dark' |
        'primary-light' |
        'secondary-base' |
        'secondary-dark' |
        'secondary-light' |
        'supplementary-blue' |
        'supplementary-lavender' |
        'supplementary-mint' |
        'supplementary-pink' |
        'tertiary-base' |
        'tertiary-dark' |
        'tertiary-light' |
        'utility-blue' |
        'utility-green' |
        'utility-red' |
        'utility-yellow';

    type TextType = 'header-h1' |
        'header-h2' |
        'header-h3' |
        'header-h4' |
        'header-h5' |
        'caption-sm' |
        'caption-md' |
        'caption-lg' |
        'body-xs' |
        'body-sm' |
        'body-md' |
        'body-lg' |
        'cta-sm' |
        'cta-md' |
        'cta-lg' |
        'error';

    export interface ITextProps extends HTMLAttributes<HTMLElement> {
        type?: TextType;
        dataTestId?: string;
        inline?: boolean;
        tag?: keyof JSX.IntrinsicElements;
        color?: ColorType;
        children: React.ReactNode;
    };
}