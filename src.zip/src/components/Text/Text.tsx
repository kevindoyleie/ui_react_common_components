import React from 'react';
import styles from './Text.module.scss';
import { TextType } from './Text.types';

/**
 * The Text component is used to render a text.
 * 
 * Customization details in Usage.readme
 */
export function Text({ type = 'body-md', className = '', children, inline, dataTestId = 'cmn-text', color = 'grey-black', tag = 'p' }: TextType.ITextProps) {
  let Component = tag;
  let componentClass = styles[type]; 
  const headerTypes = ['header-h1', 'header-h2', 'header-h3', 'header-h4', 'header-h5'];

  if (headerTypes.includes(type)) {
    switch (type) {
    case 'header-h1': Component = 'h1'; break;
    case 'header-h2': Component = 'h2'; break;
    case 'header-h3': Component = 'h3'; break;
    case 'header-h4': Component = 'h4'; break;
    case 'header-h5':
    default: Component = 'h5'; break;
    }
  }

  if (inline) {
    componentClass += ` ${styles.inline}`;
  }

  if (color) {
    componentClass += ` color-${color}`;
  }

  return (
    <Component className={`${componentClass} ${className}`} data-testid={dataTestId}>{children}</Component>
  );
}