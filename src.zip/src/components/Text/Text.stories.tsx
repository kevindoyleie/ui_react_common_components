import React from 'react';
import { Text } from './Text';
import { ComponentStory, ComponentMeta } from '@storybook/react';

export default {
  title: 'Miscellaneous/Text',
  component: Text,
} as ComponentMeta<typeof Text>;

const TextTemplate: ComponentStory<typeof Text> = (args) => <Text {...args} >Text</Text>;

TextTemplate.args = {
  type: 'body-md',
  className: '',
  inline: false,
  dataTestId: '',
};

export const H1 = TextTemplate.bind({});
H1.args = {
  ...TextTemplate.args,
  type: 'header-h1',
}
export const H2 = TextTemplate.bind({});
H2.args = {
  ...TextTemplate.args,
  type: 'header-h2',
}
export const H3 = TextTemplate.bind({});
H3.args = {
  ...TextTemplate.args,
  type: 'header-h3',
}
export const H4 = TextTemplate.bind({});
H4.args = {
  ...TextTemplate.args,
  type: 'header-h4',
}
export const H5 = TextTemplate.bind({});
H5.args = {
  ...TextTemplate.args,
  type: 'header-h5',
}

export const CaptionSm = TextTemplate.bind({});
CaptionSm.args = {
  ...TextTemplate.args,
  type: 'caption-sm',
}
export const CaptionMd = TextTemplate.bind({});
CaptionMd.args = {
  ...TextTemplate.args,
  type: 'caption-md',
}
export const CaptionLg = TextTemplate.bind({});
CaptionLg.args = {
  ...TextTemplate.args,
  type: 'caption-lg',
}

export const BodyXs = TextTemplate.bind({});
BodyXs.args = {
  ...TextTemplate.args,
  type: 'body-xs',
}
export const BodySm = TextTemplate.bind({});
BodySm.args = {
  ...TextTemplate.args,
  type: 'body-sm',
}
export const BodyMd = TextTemplate.bind({});
BodyMd.args = {
  ...TextTemplate.args,
  type: 'body-md',
}
export const BodyLg = TextTemplate.bind({});
BodyLg.args = {
  ...TextTemplate.args,
  type: 'body-lg',
}

export const CtaSm = TextTemplate.bind({});
CtaSm.args = {
  ...TextTemplate.args,
  type: 'cta-sm',
}
export const CtaMd = TextTemplate.bind({});
CtaMd.args = {
  ...TextTemplate.args,
  type: 'cta-md',
}
export const CtaLg = TextTemplate.bind({});
CtaLg.args = {
  ...TextTemplate.args,
  type: 'cta-lg',
}

export const Error = TextTemplate.bind({});
Error.args = {
  ...TextTemplate.args,
  type: 'error',
}
