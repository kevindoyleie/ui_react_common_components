import React from 'react';
import { render } from '@testing-library/react';
import { Text } from './Text';

describe('Renders text component', () => {
  describe('header snapshot test', () => {
    it('h1', () => {
      const { getByText, container } = render(<Text type="header-h1">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('header-h1').length).toBe(1);
    });
    it('h2', () => {
      const { getByText, container } = render(<Text type="header-h2">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('header-h2').length).toBe(1);
    });
    it('h3', () => {
      const { getByText, container } = render(<Text type="header-h3">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('header-h3').length).toBe(1);
    });
    it('h4', () => {
      const { getByText, container } = render(<Text type="header-h4">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('header-h4').length).toBe(1);
    });
    it('h5', () => {
      const { getByText, container } = render(<Text type="header-h5">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('header-h5').length).toBe(1);
    });
  });
  describe('caption snapshot test', () => {
    it('caption - lg', () => {
      const { getByText, container } = render(<Text type="caption-lg">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('caption-lg').length).toBe(1);
    });
    it('caption - sm', () => {
      const { getByText, container } = render(<Text type="caption-sm">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('caption-sm').length).toBe(1);
    });
    it('caption - md', () => {
      const { getByText, container } = render(<Text type="caption-md">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('caption-md').length).toBe(1);
    });
  });
  describe('body snapshot test', () => {
    it('body - lg', () => {
      const { getByText, container } = render(<Text type="body-lg">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('body-lg').length).toBe(1);
    });
    it('body - sm', () => {
      const { getByText, container } = render(<Text type="body-sm">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('body-sm').length).toBe(1);
    });
    it('body - xs', () => {
      const { getByText, container } = render(<Text type="body-xs">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('body-xs').length).toBe(1);
    });
    it('body - md', () => {
      const { getByText, container } = render(<Text type="body-md">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('body-md').length).toBe(1);
    });
  });
  describe('cta snapshot test', () => {
    it('cta - lg', () => {
      const { getByText, container } = render(<Text type="cta-lg">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('cta-lg').length).toBe(1);
    });
    it('cta - sm', () => {
      const { getByText, container } = render(<Text type="cta-sm">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('cta-sm').length).toBe(1);
    });
    it('cta - md', () => {
      const { getByText, container } = render(<Text type="cta-md">Test</Text>);
      expect(getByText('Test')).toBeTruthy();
      expect(container.getElementsByClassName('cta-md').length).toBe(1);
    });
  });
  it('error snapshot test', () => {
    const { getByText, container } = render(<Text type="error">Test</Text>);
    expect(getByText('Test')).toBeTruthy();
    expect(container.getElementsByClassName('error').length).toBe(1);
  });
  it('color and paragraph snapshot test', () => {
    const { getByText, container } = render(<Text type="body-md" color="grey-black" inline>Test</Text>);
    expect(getByText('Test')).toBeTruthy();
    expect(container.getElementsByClassName('inline').length).toBe(1);
  });
});