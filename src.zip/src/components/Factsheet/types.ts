import { ReactElement } from 'react';
import { AccordionType } from '../Accordion';

export namespace FactsheetType {
  export type Link = ReactElement;
  export type IContent = {
    heading: string;
    links: Link[];
    linksText: ReactElement[];
    benefitsContent: AccordionType.Item[];
  };
  export interface IProps {
    id?: string;
    dataTestId?: string;
    content: IContent;
    showModal: boolean;
    setShowModal: (arg: boolean) => void;
  }

  export interface IHeaderProps {
    heading: string;
  }

  export interface IBodyProps {
    id?: string;
    dataTestId?: string;
    benefitsContent: AccordionType.Item[];
    links: Link[];
    linksText: ReactElement[];
  }
}
