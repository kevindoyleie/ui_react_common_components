import React from 'react';
import { screen, render } from '@testing-library/react';
import Factsheet from './Factsheet';
import { content } from './FactsheetData';

describe('Testing Factsheet', () => {
  test('Check if Factsheet is rendered when modal is opened', async () => {
    const showModal = true;
    const setShowModal = jest.fn();

    render(<Factsheet content={content} showModal={showModal} setShowModal={setShowModal} />);

    const factsheet = document.querySelector('.modal-dialog');

    expect(factsheet).toBeInTheDocument();
  });

  test('Check if Factsheet is not rendered when modal is closed', async () => {
    const showModal = false;
    const setShowModal = jest.fn();

    render(<Factsheet content={content} showModal={showModal} setShowModal={setShowModal} />);

    expect(screen.queryByText('PremiumCare', { exact: false })).not.toBeInTheDocument();
  });

  test('Check if the Accordion in Factsheet Body is rendered when modal is opened', async () => {
    const showModal = true;
    const setShowModal = jest.fn();

    render(<Factsheet content={content} showModal={showModal} setShowModal={setShowModal} />);

    const factsheetAccordion = screen.getByText('Your hospital accommodation', { exact: false });

    expect(factsheetAccordion).toBeInTheDocument();
  });

  test('Check if Factsheet Heading is rendered', async () => {
    const showModal = true;
    const setShowModal = jest.fn();

    render(<Factsheet content={content} showModal={showModal} setShowModal={setShowModal} />);

    const factsheetHeading = screen.getByText('PremiumCare', { exact: false });

    expect(factsheetHeading).toBeInTheDocument();
  });
});
