import React from 'react';
import { GenericModal, ModalType } from '../Modals';
import FactsheetBody from './FactsheetBody/FactsheetBody';
import FactsheetHeader from './FactsheetHeader/FactsheetHeader';
import { FactsheetType } from './types';
import Styles from './factsheet.module.scss';

/**
 * Factsheet component acts as a custom wrapper using Generic Modal and Accordion components.
 *
 * Content for both the modal and accordion is passed through props.
 * The Accordion component is being rendered in the body of Factsheet.
 */

function Factsheet({
  id = 'cmn-factsheet',
  dataTestId = 'cmn-factsheet',
  content,
  showModal,
  setShowModal,
}: FactsheetType.IProps) {
  const { benefitsContent, heading, links, linksText } = content;
  const { ['factsheet-cta']: factsheetCta, ['modal-width']: modalWidth } = Styles;
  const factsheetContent: ModalType.IContent = {
    modalContent: {
      ctas: [
        {
          id: 'cta-close',
          text: 'Close',
          ctaClassName: factsheetCta,
        },
      ],
      customContent: {
        header: <FactsheetHeader heading={heading} />,
        body: (
          <FactsheetBody
            id={id}
            dataTestId={dataTestId}
            benefitsContent={benefitsContent}
            links={links}
            linksText={linksText}
          />
        ),
      },
    },
  };

  return (
    <GenericModal
      dataTestId={dataTestId}
      dialogClassName={modalWidth}
      content={factsheetContent}
      showModal={showModal}
      setShowModal={setShowModal}
    />
  );
}

export default Factsheet;
