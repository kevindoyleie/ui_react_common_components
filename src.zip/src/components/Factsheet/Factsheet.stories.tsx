import React, { useState } from 'react';
import Factsheet from './Factsheet';
import { content } from './FactsheetData';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { FactsheetType } from './types';

export default {
  title: 'Miscellaneous/Factsheet',
  component: Factsheet,
} as ComponentMeta<typeof Factsheet>;

const testId = 'factsheet-testid';

const Template: ComponentStory<typeof Factsheet> = (args: FactsheetType.IProps) => {
  const [showModal, setShowModal] = useState(false);

  const handleClick = () => {
    setShowModal(true);
  };

  return (
    <>
      <button onClick={handleClick}>Show Benefits</button>
      {showModal && (
        <Factsheet
          id={args.id}
          dataTestId={args.dataTestId}
          content={args.content}
          showModal={showModal}
          setShowModal={setShowModal}
        />
      )}
    </>
  );
};

export const Default = Template.bind({});
Default.args = {
  id: testId,
  dataTestId: testId,
  content,
};
