import React from 'react';
import { FactsheetType } from './types';

const DemoItem = () => {
  return (
    <div>
      <p>A private room in a wide range of public and private hospitals</p>
      <p>
        Full cover for medical treatments and surgical procedures, including ophthalmic and orthopaedic procedures in all
        public and private hospitals.
      </p>
      <p>2,500 in-patient consultants.</p>
      <p>New advanced treatments in areas such as cardiac and cancer care.</p>
      <p>Medical costs of in-patient diagnosis and tests covered too.</p>
    </div>
  );
};

const links = [
  <p key={0}>
    <a href="https://www.vhi.ie/pdf/myvhi/TOBPREMCARE%20V12%20Sep22.pdf">Table of Benefits</a>
  </p>,
  <p key={1}>
    <a href="https://www.vhi.ie/pdf/products/Hospital%20Plans%20Rules_01Sep22_HLRD32.pdf">Terms & Conditions</a>
  </p>,
  <p key={2}>
    <a href="https://www.vhi.ie/pdf/ipid/IPID_PremiumCare_V4_1Sep2022.pdf">Insurance Product Information (IPID)</a>
  </p>,
  <p key={3}>
    <a href="https://app.vhi.ie/facilityfinder">Facility Finder</a>
  </p>,
];

const content: FactsheetType.IContent = {
  heading: 'PremiumCare',
  links: links,
  linksText: [
    <p key={0}>
      The plan benefits shown here apply to policies purchased and effective today. Plan benefits are updated occasionally.
    </p>,
    <p key={1}>Waiting periods may apply. Please read the Terms and Conditions to find out more.</p>,
  ],
  benefitsContent: [
    {
      title: 'Your hospital accommodation – what you’re covered for…',
      content: <DemoItem />,
    },
    {
      title: 'Day-to-day benefits - what’s included...',
      content:
        'The excess means that when your eligible benefits have exceeded the value of €1, we will then pay remaining eligible benefits right up to the value of €2,000. Take a moment to review the Table of Benefits for more details.',
    },
    {
      title: 'Health Screening Programme...',
      content: 'Get peace of mind with one of our screening programmes in each 24 month period',
    },
    {
      title: 'Cardiac Care Programme',
      content:
        'Full cover in all hospitals including Blackrock Clinic and Mater Private for all cardiac procedures including specialised minimally invasive cardiac procedures such as Tavi and LAA Occlusion which are often carried out in these two hospitals.',
    },
    {
      title: 'Vhi 360 Health Centres - dedicated benefits for Vhi members',
      content: 'Health and wellbeing services delivered by a multidisciplinary team.',
    },
  ],
};

// Example mapper for providing unique id and dataTestId for Factsheet
content.benefitsContent.map((item, index: number) => {
  item.id = `${'cmn-factsheet-accordion'}-${item.title}-${index}`;
  item.dataTestId = `${'cmn-factsheet-accordion'}-${item.title}-${index}`;
});

export { content };
