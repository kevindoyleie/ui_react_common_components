import React, { useState, useMemo } from 'react';
import { Accordion, ExpandAllButton } from '../../Accordion';
import { FactsheetType } from '../types';
import Styles from './body.module.scss';

function FactsheetBody({ id, dataTestId, benefitsContent, links, linksText }: FactsheetType.IBodyProps) {
  const [expanded, setExpanded] = useState<number[]>([]);
  const [disabled, setDisabled] = useState(false);
  const {
    ['factsheet-body']: factsheetBody,
    ['expand-all-container']: expandAllContainer,
    ['static-content-container']: staticContentContainer,
    ['factsheet-links-container']: factsheetLinksContainer,
  } = Styles;

  const memoizedAllExpandItems = useMemo(() => benefitsContent.map((i) => benefitsContent.indexOf(i)), [benefitsContent]);

  return (
    <div className={factsheetBody}>
      <div className={expandAllContainer}>
        <ExpandAllButton
          id={`${id}-ExpandAllButton`}
          dataTestId={`${dataTestId}-ExpandAllButton`}
          setExpanded={setExpanded}
          setDisabled={setDisabled}
          allItems={memoizedAllExpandItems}
        />
      </div>

      <Accordion
        titleUppercase={false}
        bottomBorder={false}
        items={benefitsContent}
        expanded={expanded}
        setExpanded={setExpanded}
        disabled={disabled}
      />
      <div id={`${id}-LinksText-div`} data-testid={`${dataTestId}-LinksText-div`} className={staticContentContainer}>
        {linksText.map((text, index) => (
          <React.Fragment key={index}>{text}</React.Fragment>
        ))}
      </div>
      <div
        id={`${id}-LinksContainer-div`}
        data-testid={`${dataTestId}-LinksContainer-div`}
        className={factsheetLinksContainer}
      >
        {links.map((link, index) => (
          <React.Fragment key={index}>{link}</React.Fragment>
        ))}
      </div>
    </div>
  );
}

export default FactsheetBody;
