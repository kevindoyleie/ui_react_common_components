import React from 'react';
import { FactsheetType } from '../types';
import Styles from './header.module.scss';

function FactsheetHeader({ heading }: FactsheetType.IHeaderProps) {
  const { ['factsheet-header']: factsheetHeader } = Styles;
  return (
    <div className={factsheetHeader}>
      <span>{heading}</span>
    </div>
  );
}

export default FactsheetHeader;
