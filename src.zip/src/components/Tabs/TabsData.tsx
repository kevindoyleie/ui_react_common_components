import React, { ReactElement } from 'react';
import { TabsType } from './types';

const DemoItem = (item: string): ReactElement => {
  return <p>This is a child component: {item}</p>;
};

export const data: TabsType.TabItem[] = [
  {
    tabKey: 'find-member',
    heading: 'Find member',
    subHeading: 'By policy number or member detail',
    insideComponent: DemoItem('find member'),
  },
  {
    tabKey: 'cover-plans',
    heading: 'Cover plans',
    subHeading: 'Find benefits by Cover Plan',
    insideComponent: DemoItem('cover plans'),
  },
  {
    tabKey: 'online-schedule',
    heading: 'Online schedule',
    subHeading: 'Find professional schedule',
    insideComponent: DemoItem('online schedule'),
    disabled: true,
  },
];
