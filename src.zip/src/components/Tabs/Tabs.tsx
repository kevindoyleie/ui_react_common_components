import React, { memo, ReactElement, useState } from 'react';
import Tab from 'react-bootstrap/Tab';
import Nav from 'react-bootstrap/Nav';
import Styles from './tabs.module.scss';
import { TabsType } from './types';

/**
 * The tabs component is used to create dynamic tabbed navigation interfaces.
 * Tabs is a higher-level component for quickly creating a Nav matched with a set of TabPanes
 */
export const Tabs = memo(({ items, initialTabKey }: TabsType.ITabsProps): ReactElement => {
  const [activeKey, setActiveKey] = useState<TabsType.EventKey>(initialTabKey || items[0].tabKey);

  return (
    <div id="cmn-tabs" data-testid="cmn-tabs" className={Styles.Tabs}>
      <Tab.Container mountOnEnter activeKey={activeKey} onSelect={(value) => value && setActiveKey(value)}>
        <Nav>
          {items.map((item) => (
            <Nav.Item key={item.tabKey}>
              <Nav.Link
                eventKey={item.tabKey}
                className="tabs-link"
                active={activeKey === item.tabKey}
                disabled={item.disabled}
              >
                <h3>{item.heading}</h3>
                <p>{item.subHeading}</p>
              </Nav.Link>
            </Nav.Item>
          ))}
        </Nav>
        <Tab.Content>
          {items.map((item) => (
            <Tab.Pane key={item.tabKey} eventKey={item.tabKey} mountOnEnter={true}>
              {item.insideComponent}
            </Tab.Pane>
          ))}
        </Tab.Content>
      </Tab.Container>
    </div>
  );
});

Tabs.displayName = 'Tabs';

export default Tabs;
