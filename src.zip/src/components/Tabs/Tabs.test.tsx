import React from 'react';
import { fireEvent, render } from '@testing-library/react';

import { Tabs } from './Tabs';
import { data } from './TabsData';
import { TabsType } from './types';

describe('Testing Tabs', () => {
  const props: TabsType.ITabsProps = {
    items: data,
    initialTabKey: 'cover-plans',
  };

  test('should render the tab heading', () => {
    const { getByText } = render(<Tabs {...props} />);

    expect(getByText('Find member')).toBeTruthy();
    expect(getByText('Cover plans')).toBeTruthy();
    expect(getByText('Online schedule')).toBeTruthy();
  });

  test('should render the tab subHeading', () => {
    const { getByText } = render(<Tabs {...props} />);

    expect(getByText('By policy number or member detail')).toBeTruthy();
    expect(getByText('Find benefits by Cover Plan')).toBeTruthy();
    expect(getByText('Find professional schedule')).toBeTruthy();
  });

  test('should render content only for tab set as initialTabKey', () => {
    const { getByText, queryByText } = render(<Tabs {...props} />);

    expect(queryByText('This is a child component: find member')).toBeFalsy();
    expect(getByText('This is a child component: cover plans')).toBeTruthy();
    expect(queryByText('This is a child component: online schedule')).toBeFalsy();
  });

  test('should render content for tab once clicked', () => {
    const { getByText, queryByText } = render(<Tabs {...props} />);

    fireEvent.click(getByText('Find member'));

    expect(getByText('This is a child component: find member')).toBeTruthy();
    expect(getByText('This is a child component: cover plans')).toBeTruthy();
    expect(queryByText('This is a child component: online schedule')).toBeFalsy();
  });

  test('should not render content for disabled tab once clicked', () => {
    const { getByText, queryByText } = render(<Tabs {...props} />);

    fireEvent.click(getByText('Online schedule'));

    expect(queryByText('This is a child component: find member')).toBeFalsy();
    expect(getByText('This is a child component: cover plans')).toBeTruthy();
    expect(queryByText('This is a child component: online schedule')).toBeFalsy();
  });
});
