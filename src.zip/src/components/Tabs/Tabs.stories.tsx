import React from 'react';
import { Tabs } from './Tabs';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { data } from './TabsData';

export default {
  title: 'Layout/Tabs',
  component: Tabs,
} as ComponentMeta<typeof Tabs>;

const Template: ComponentStory<typeof Tabs> = (args) => <Tabs {...args} />;

export const Default = Template.bind({});

Default.args = {
  items: data,
};
