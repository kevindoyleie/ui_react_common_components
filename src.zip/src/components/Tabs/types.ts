import { ReactElement } from 'react';

export namespace TabsType {
  export type EventKey = string;

  export interface ITabsProps {
    items: TabItem[];
    initialTabKey?: string;
  }

  export interface TabItem {
    tabKey: string;
    heading: string;
    subHeading: string;
    insideComponent: ReactElement;
    disabled?: boolean;
  }
}
