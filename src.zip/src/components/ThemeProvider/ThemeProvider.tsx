import React from 'react';
import { ThemeProvider as MuiThemeProvider } from '@mui/material/styles';
import { muiTheme } from '../../theme';

interface IThemeProps {
  children: JSX.Element;
}

function ThemeProvider({ children }: IThemeProps) {
  return <MuiThemeProvider theme={muiTheme}>{children}</MuiThemeProvider>;
}

export default ThemeProvider;
