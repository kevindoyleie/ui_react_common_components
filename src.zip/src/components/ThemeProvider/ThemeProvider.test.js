import { screen, render, waitFor } from '@testing-library/react';
import ThemeProvider from './ThemeProvider';
import { muiTheme } from '../../theme';

describe('Testing Theme Provider', () => {
  const children = <div>test text</div>;

  test('check for button appearing', async () => {
    render(<ThemeProvider theme={muiTheme}>{children}</ThemeProvider>);

    expect(screen.getByText('test text')).toBeInTheDocument();
  });
});
