import React, { useEffect, useState, CSSProperties } from 'react';
import { wrapCookieBanner } from './CookieBanner.utils';
import { useExternalScript } from 'lib_web-common-utilities';
import cookieIcon from './cookieIcon.png';
import { CookieBannerType } from './types';

const CookieBanner = ({ url, domainScript }: CookieBannerType.IProps): JSX.Element => {
  const styles: CSSProperties = {
    position: 'fixed',
    left: '0',
    bottom: '0',
    zIndex: '2147483648',
    backgroundImage: `url(${cookieIcon})`,
    backgroundColor: 'transparent',
    height: '35px',
    width: '35px',
    padding: '0',
    border: '0px',
    fontSize: '0px',
  };
  const [consent, setConsent] = useState(false);

  const scriptState = useExternalScript(url, domainScript);

  useEffect(() => {
    if (scriptState === 'ready') {
      let tries = 0;

      const interval = setInterval(() => {
        if (tries > 15) {
          clearInterval(interval);
        }

        if (typeof window.Optanon !== 'undefined' && document.getElementsByClassName('privacy-notice-link').length) {
          clearInterval(interval);
          wrapCookieBanner(consent, setConsent);
        }

        tries++;
      }, 100);
    }
  }, [scriptState]);

  return <button id="ot-sdk-btn" data-testid="ot-sdk-btn" className="ot-sdk-show-settings" style={styles} />;
};

export default CookieBanner;
