import React from 'react';
import CookieBanner from './CookieBanner';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { CookieBannerType } from './types';

export default {
  title: 'Miscellaneous/CookieBanner',
  component: CookieBanner,
} as ComponentMeta<typeof CookieBanner>;

const Template: ComponentStory<typeof CookieBanner> = (args: CookieBannerType.IProps) => {
  return <CookieBanner {...args} />;
};

const URL = 'https://cdn.cookielaw.org/scripttemplates/otSDKStub.js';
const DOMAIN_SCRIPT = '5dc092f8-8e4b-4b8f-a78d-4a2e2835ce14-test';

export const Default = Template.bind({});
Default.args = {
  dataTestId: 'cookie-banner',
  url: URL,
  domainScript: DOMAIN_SCRIPT,
};
