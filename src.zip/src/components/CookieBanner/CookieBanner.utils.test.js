import { getCookie, wrapCookieBanner } from './CookieBanner.utils';

describe('Testing CookieBanner utils', () => {
  Object.defineProperty(global.document, 'cookie', {
    writable: true,
    value: '_ga=123123',
  });

  test('check getCookie function ', async () => {
    const cookie1 = '_ga';

    expect(getCookie(cookie1)).toBe('123123');
  });

  test('check wrapCookieBanner function ', async () => {
    const elem = document.createElement('a');

    const spyFunc = jest.fn().mockImplementation(() => [elem]);
    const spyOptanonFunc = jest.fn();

    Object.defineProperty(global.document, 'getElementsByClassName', {
      writable: true,
      value: spyFunc,
    });

    Object.defineProperties(global, {
      dataLayer: { value: [] },
      Optanon: { value: { ToggleInfoDisplay: spyOptanonFunc } },
    });

    wrapCookieBanner(false, jest.fn());

    expect(spyFunc).toHaveBeenCalled();
    expect(spyOptanonFunc).toHaveBeenCalled();
  });
});
