export namespace CookieBannerType {
  export interface IProps {
    dataTestId: string;
    domainScript: string;
    url: string;
  }
}
