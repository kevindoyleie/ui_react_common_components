import { screen, render, waitFor } from '@testing-library/react';
import CookieBanner from './CookieBanner';

jest.mock('lib_web-common-utilities', () => ({
  useExternalScript: () => 'ready',
}));

jest.mock('./CookieBanner.utils', () => ({
  wrapCookieBanner: jest.fn(),
}));

describe('Testing Cookie Banner', () => {
  const URL = 'https://cdn.cookielaw.org/scripttemplates/otSDKStub.js';
  const DOMAIN_SCRIPT = '5dc092f8-8e4b-4b8f-a78d-4a2e2835ce14-test';

  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  test('check for button appearing', async () => {
    render(<CookieBanner url={URL} domainScript={DOMAIN_SCRIPT} />);
    jest.advanceTimersByTime(3000);

    await waitFor(() => {
      expect(screen.getByTestId('ot-sdk-btn')).toBeInTheDocument();
    });
  });
});
