export function wrapCookieBanner(consent: boolean, setConsent: (hasConsent: boolean) => void) {
  window.dataLayer.push({ event: 'OneTrustGroupsUpdated' });

  const link = document.getElementsByClassName('privacy-notice-link');
  link[0].setAttribute('href', 'https://www.vhi.ie/cookies');

  if (!getCookie('OptanonAlertBoxClosed') && !consent) {
    setConsent(true);
    window.Optanon.ToggleInfoDisplay();
  }
}

export function getCookie(name: string) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);

  if (parts.length == 2) {
    const lastElement = parts.pop() as string;
    return lastElement.split(';').shift();
  }
}
