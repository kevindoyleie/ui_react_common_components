import React from 'react';
import Modal from 'react-bootstrap/Modal';
import AjaxLoader from './ajax-loader.gif';
import Styles from './modalSpinner.scss';
import { ModalSpinnerType } from './types';

const ModalSpinner = ({ show }: ModalSpinnerType.IProps): JSX.Element => (
  <Modal centered show={show} size="sm">
    <Modal.Body>
      <div className={Styles['modal-spinner']}>
        <img src={AjaxLoader} alt="loading" />
      </div>
    </Modal.Body>
  </Modal>
);

export default ModalSpinner;
