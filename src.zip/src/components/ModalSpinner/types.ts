export namespace ModalSpinnerType {
  export interface IProps {
    show: boolean;
  }
}
