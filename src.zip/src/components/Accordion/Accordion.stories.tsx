import React, { useState } from 'react';
import Accordion from './Accordion';
import ExpandAllButton from './ExpandAllButton/ExpandAllButton';
import ExpandMoreLargeIcon from './icon-large-arrow-purple.svg';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { data } from './AccordionData';

export default {
  title: 'Miscellaneous/Accordion',
  component: Accordion,
} as ComponentMeta<typeof Accordion>;

const Template: ComponentStory<typeof Accordion> = (args) => {
  const { items } = args;
  const [expanded, setExpanded] = useState<number[]>([]);
  const [buttonExpanded, setButtonExpanded] = useState<boolean>(false);
  const [disabled, setDisabled] = useState<boolean>(false);

  return (
    <>
      <ExpandAllButton
        setExpanded={setExpanded}
        setDisabled={setDisabled}
        buttonExpanded={buttonExpanded}
        setButtonExpanded={setButtonExpanded}
        allItems={[...items.map((i) => items.indexOf(i))]}
        color="secondary"
      />
      <Accordion {...args} expanded={expanded} setExpanded={setExpanded} disabled={disabled} />
      {buttonExpanded && (
        <ExpandAllButton
          setExpanded={setExpanded}
          setDisabled={setDisabled}
          buttonExpanded={buttonExpanded}
          setButtonExpanded={setButtonExpanded}
          allItems={[...items.map((i) => items.indexOf(i))]}
          color="secondary"
        />
      )}
    </>
  );
};

export const WithControls = Template.bind({});

WithControls.argTypes = {
  titleColor: {
    control: { type: 'radio' },
    options: ['secondary', 'default'],
  },
};

WithControls.args = {
  items: data,
  titleCentered: false,
  titleColor: 'secondary',
  bottomBorder: true,
  titleTruncate: true,
  titleUppercase: true,
};

const Template2: ComponentStory<typeof Accordion> = (args) => <Accordion {...args} />;

export const WithoutControls = Template2.bind({});

WithoutControls.argTypes = {
  titleColor: {
    control: { type: 'radio' },
    options: ['secondary', 'default'],
  },
};

WithoutControls.args = {
  items: data,
  titleCentered: false,
  titleColor: 'default',
  bottomBorder: false,
  titleTruncate: false,
  titleUppercase: false,
};

const Template3: ComponentStory<typeof ExpandAllButton> = (args) => <ExpandAllButton {...args} />;

export const ExpandButton = Template3.bind({});

ExpandButton.argTypes = {
  color: {
    control: { type: 'radio' },
    options: ['secondary', 'default'],
  },
};

ExpandButton.args = {
  allItems: [0, 1, 2, 3],
  color: 'default',
  closeText: 'Close all',
  openText: 'Open all',
  setDisabled: () => true,
  setExpanded: () => true,
};

const BlockAccordionsTemplate: ComponentStory<typeof Accordion> = (args) => <Accordion {...args} />;

export const BlockAccordions = BlockAccordionsTemplate.bind({});

BlockAccordions.argTypes = {
  titleColor: {
    control: { type: 'radio' },
    options: ['secondary', 'default'],
  },
};

BlockAccordions.args = {
  items: data,
  titleCentered: false,
  titleColor: 'default',
  bottomBorder: false,
  titleTruncate: false,
  titleUppercase: false,
  type: 'block',
  expandIcon: <img src={ExpandMoreLargeIcon} alt="expand" />
};
