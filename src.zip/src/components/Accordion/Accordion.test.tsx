import React from 'react';
import { screen, render, waitFor, fireEvent } from '@testing-library/react';
import Accordion from './Accordion';

describe('Testing Accordion', () => {
  const TEST_TITLE = 'test title';
  const TEST_CONTENT = 'test content';

  const data = [{ title: TEST_TITLE, content: TEST_CONTENT }];
  test('check if Accordion is rendered', async () => {
    render(<Accordion items={data} />);
    const accordion = document.querySelector('.MuiAccordion-root');

    expect(accordion).toBeInTheDocument();
  });

  test('check if Accordion expands', async () => {
    render(<Accordion items={data} />);

    fireEvent.click(screen.getByText(TEST_TITLE));

    await waitFor(() => {
      expect(document.querySelector('.Mui-expanded')).toBeInTheDocument();
    });
  });

  test('check if block Accordion is rendered', async () => {
    render(<Accordion items={data} type="block" />);
    const accordion = document.querySelector('.MuiAccordion-root');

    expect(accordion).toBeInTheDocument();
  });
});
