import { AccordionType } from './types';

export const getAdditionalStyling = ({
  Styles,
  titleCentered,
  titleColor,
  bottomBorder,
  titleTruncate,
  titleUppercase,
}: AccordionType.IAdditionalStyling) => {
  const classes = [];
  const {
    centered,
    ['color-default']: colorDefault,
    ['color-secondary']: colorSecondary,
    ['border-bottom']: borderBottom,
    truncate,
    uppercase,
  } = Styles;

  if (titleCentered) {
    classes.push(centered);
  }

  if (titleColor) {
    titleColor === 'default' ? classes.push(colorDefault) : classes.push(colorSecondary);
  }

  if (bottomBorder) {
    classes.push(borderBottom);
  }

  if (titleTruncate) {
    classes.push(truncate);
  }

  if (titleUppercase) {
    classes.push(uppercase);
  }

  return classes.join(' ');
};
