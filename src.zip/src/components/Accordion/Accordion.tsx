import React, { useState } from 'react';
import { AccordionType } from './types';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import MuiAccordion from '@mui/material/Accordion';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import { getAdditionalStyling } from './Accordion.utils';
import Styles from './accordion.module.scss';

/**
 * The Accordion component allows the user to show and hide sections of related content on a page.
 * Can be used with ExpandAllButton component to handle expanding/collapsing all sections.
 *
 * Styling and content are dynamic.
 * 
 * Customization details in Usage.readme
 */
function Accordions({
  items,
  expanded,
  disabled = false,
  setExpanded,
  titleUppercase = true,
  titleCentered = false,
  titleColor = 'default',
  bottomBorder = true,
  titleTruncate = false,
  type = 'default',
  expandIcon = <ExpandMoreIcon />
}: AccordionType.IProps) {
  const [innerExpanded, setInnerExpanded] = useState<number[]>(expanded || []);

  const additionalClasses = getAdditionalStyling({
    Styles,
    titleCentered,
    titleColor,
    bottomBorder,
    titleTruncate,
    titleUppercase,
  });

  const wrapperClassName = type === 'default' ? Styles.accordion : Styles.blockAccordion;

  const handleChange = (panel: number) => (event: React.SyntheticEvent, newExpanded: boolean) => {
    setExpanded ? setExpanded(newExpanded ? [panel] : []) : setInnerExpanded(newExpanded ? [panel] : []);
  };

  return (
    <>
      {items.map((item, key: number) => {
        const { title, content, id, dataTestId } = item;

        return (
          <div key={key} className={wrapperClassName}>
            <MuiAccordion
              disableGutters
              elevation={0}
              id={id ? id : `cmn-accordion-${key}`}
              data-testid={dataTestId ? dataTestId : `cmn-accordion-${key}`}
              square
              className={additionalClasses}
              disabled={disabled}
              expanded={expanded ? expanded.includes(key) : innerExpanded.includes(key)}
              onChange={handleChange(key)}
            >
              <MuiAccordionSummary expandIcon={expandIcon} aria-controls={`panel${key}-title`}>
                <div>{title}</div>
              </MuiAccordionSummary>
              <MuiAccordionDetails>
                <div>{content}</div>
              </MuiAccordionDetails>
            </MuiAccordion>
          </div>
        );
      })}
    </>
  );
}

export default Accordions;
