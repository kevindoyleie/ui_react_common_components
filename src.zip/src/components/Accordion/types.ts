import { ReactElement } from 'react';
import { AccordionProps, AccordionSummaryProps } from '@mui/material';

export namespace AccordionType {
  export type Item = {
    title: string | ReactElement;
    content?: string | ReactElement;
    id?: string;
    dataTestId?: string;
  };

  export interface IProps {
    items: Item[];
    children?: JSX.Element;
    expanded?: number[];
    disabled?: boolean;
    setExpanded?: (arg: number[]) => void;
    titleCentered?: boolean;
    titleColor?: 'default' | 'secondary';
    bottomBorder?: boolean;
    titleTruncate?: boolean;
    titleUppercase?: boolean;
    expandIcon?: JSX.Element,
    type?: 'default' | 'block'
  }

  export interface ICustomAccordionProps extends AccordionProps {
    bottomBorder?: boolean;
  }
  export interface ICustomSummaryProps extends AccordionSummaryProps {
    titleCentered?: boolean;
    titleColor?: string;
    textTruncate?: boolean;
    titleUnderline?: boolean;
    titleUppercase?: boolean;
  }

  export interface IExpandButtonProps {
    dataTestId?: string;
    id?: string;
    allItems: number[];
    color?: 'default' | 'secondary';
    closeText?: string;
    openText?: string;
    setDisabled: (arg: boolean) => void;
    setExpanded: (args: number[]) => void;
    setButtonExpanded?: ((arg: boolean) => void) | undefined;
    buttonExpanded?: boolean;
  }

  export interface IAdditionalStyling {
    Styles: any;
    titleCentered: boolean;
    titleColor: 'default' | 'secondary';
    bottomBorder: boolean;
    titleTruncate: boolean;
    titleUppercase: boolean;
  }
}
