import React, { useState } from 'react';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { AccordionType } from '../types';
import Styles from './expand.module.scss';

function ExpandAllButton({
  dataTestId = 'cmn-expandall',
  id = 'cmn-expandall',
  setDisabled,
  setExpanded,
  setButtonExpanded,
  buttonExpanded,
  allItems,
  color = 'default',
  closeText = 'Close all',
  openText = 'Open all',
}: AccordionType.IExpandButtonProps) {
  const [innerButtonExpanded, setInnerButtonExpanded] = useState<boolean>(buttonExpanded || false);

  const handleExpandToggle = () => {
    if (innerButtonExpanded || buttonExpanded) {
      setDisabled(false);
      setExpanded([]);
    } else {
      setDisabled(true);
      setExpanded([...allItems]);
    }
    setButtonExpanded !== undefined ? setButtonExpanded(!buttonExpanded) : setInnerButtonExpanded(!innerButtonExpanded);
  };

  return (
    <span
      data-testid={dataTestId}
      id={id}
      className={`${Styles.expand}${color === 'secondary' ? ' secondary' : ''}`}
      onClick={handleExpandToggle}
    >
      {innerButtonExpanded || buttonExpanded ? (
        <>
          <span>{closeText}</span>
          <ExpandLessIcon />
        </>
      ) : (
        <>
          <span>{openText}</span>
          <ExpandMoreIcon />
        </>
      )}
    </span>
  );
}

export default ExpandAllButton;
