import { screen, render, fireEvent } from '@testing-library/react';
import ExpandAllButton from './ExpandAllButton';

describe('Testing ExpandAllButton', () => {
  const OPEN_ALL = 'Open all';
  const CLOSE_ALL = 'Close all';
  const mockSetDisabled = jest.fn();
  const mockSetExpanded = jest.fn();

  test('check if Expand Button is rendered', async () => {
    render(<ExpandAllButton setDisabled={mockSetDisabled} setExpanded={mockSetExpanded} allItems={[]} />);

    expect(screen.getByText(OPEN_ALL)).toBeInTheDocument();
  });

  test('Expand Button click', async () => {
    render(<ExpandAllButton setDisabled={mockSetDisabled} setExpanded={mockSetExpanded} allItems={[]} />);

    fireEvent.click(screen.getByText(OPEN_ALL));

    expect(screen.getByText(CLOSE_ALL)).toBeInTheDocument();

    fireEvent.click(screen.getByText(CLOSE_ALL));

    expect(screen.getByText(OPEN_ALL)).toBeInTheDocument();
  });
});
