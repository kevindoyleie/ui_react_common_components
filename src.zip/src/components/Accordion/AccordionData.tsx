import React from 'react';
import { AccordionType } from './types';

export const DemoItem = () => {
  return <div>This is a child component</div>;
};

export const data: AccordionType.Item[] = [
  {
    title: 'Hospital Care',
    content: <DemoItem />,
    id: 'id',
    dataTestId: 'datatest',
  },
  {
    title: 'Scans and MRI',
    content: 'Below is the amount you can claim back. Excess may apply - the agreed amount of each claim that you pay',
  },
  {
    title: 'Cancer Care',
    content: 'Access to a wide range of benefits, supports and treatments at all stages of a cancer journey.',
  },
  {
    title: 'Exclusive to VHI members',
    content: 'Test Description',
  },
  {
    title: 'Everyday medical expenses',
    content: 'Below is the amount you can claim back. Excess may apply - the agreed amount of each claim that you pay',
  },
  {
    title: 'Some Long Text Title for Accordion Test',
    content: 'Below is the amount you can claim back. Excess may apply - the agreed amount of each claim that you pay',
  },
];
