import { getAdditionalStyling } from './Accordion.utils';
import Styles from './accodrdion.module.scss';

describe('test utils functions', () => {
  test('test getAdditionalStyling function', () => {
    const result1 = getAdditionalStyling({
      titleCentered: false,
      Styles,
      titleColor: 'default',
      bottomBorder: false,
      titleTruncate: false,
      titleUppercase: true,
    });
    const result2 = getAdditionalStyling({
      Styles,
      titleCentered: false,
      titleColor: 'default',
      bottomBorder: true,
      titleTruncate: false,
      titleUppercase: false,
    });
    const result3 = getAdditionalStyling({
      Styles,
      titleCentered: true,
      titleColor: 'secondary',
      bottomBorder: true,
      titleTruncate: false,
      titleUppercase: true,
    });

    expect(result1).toBe('color-default uppercase');
    expect(result2).toBe('color-default border-bottom');
    expect(result3).toBe('centered color-secondary border-bottom uppercase');
  });
});
