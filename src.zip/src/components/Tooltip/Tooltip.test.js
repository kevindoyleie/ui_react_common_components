import React from 'react';
import { classes, content } from './TooltipData';
import { screen, render } from '@testing-library/react';
import Tooltip from './Tooltip';
import userEvent from '@testing-library/user-event';

describe('Testing More Info Hover', () => {
  const testId = 'cmn-more-info-hover-testid';
  const tooltipText = /Money back on everyday medical expenses/i;

  test('More Info Hover renders and hides', async () => {
    const user = userEvent.setup();
    render(<Tooltip id={testId} classes={classes} content={content} />);

    expect(screen.queryByText(tooltipText)).not.toBeInTheDocument();

    await user.hover(screen.queryByRole('button'));
    expect(screen.queryByText(tooltipText)).toBeVisible();

    await user.unhover(screen.queryByRole('button'));
    expect(screen.queryByText(tooltipText)).not.toBeInTheDocument();
  });
});
