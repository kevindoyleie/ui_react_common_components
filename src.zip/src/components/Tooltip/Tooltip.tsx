import React from 'react';
import Parser from 'html-react-parser';
import { ClickAwayListener } from '@mui/base';
import MuiTooltip from '@mui/material/Tooltip';
import TooltipText from './TooltipText';
import Styles from './tooltip.module.scss';
import { TooltipType } from './types';

/**
 * The Tooltip component is used to display a tooltip when user hovers over(desktop) or touches(mobile) a button.
 *
 * Styling and content are dynamic.
 */
const Tooltip = ({
  id,
  dataTestId,
  classes = {},
  content,
  width = '300px',
  placement = TooltipType.Placement.BOTTOM,
}: TooltipType.IProps): JSX.Element => {
  const moreInfoId = id ? id : (dataTestId as string);
  const moreInfoTestId = dataTestId ? dataTestId : id;
  const buttonId = `${moreInfoId}-button`;
  const tooltipCss = `${Styles['more-info-hover__tooltip']} ${classes.tooltipClass ?? ''}`;
  const tooltipButtonCss = `${Styles['more-info-hover__button']} ${classes.tooltipButtonClass ?? ''}`;
  const tooltipHoverCss = `${Styles['more-info-hover']} ${classes.tooltipHoverClass ?? ''}`;

  return (
    <div className={Styles['more-info']}>
      <div className={tooltipHoverCss}>
        <ClickAwayListener
          onClickAway={() => {
            /* do nothing */
          }}
        >
          <MuiTooltip
            enterDelay={0}
            enterTouchDelay={0}
            leaveTouchDelay={20000}
            placement={placement}
            title={
              <TooltipText
                moreInfoId={moreInfoId}
                moreInfoTestId={moreInfoTestId}
                tooltipClass={tooltipCss}
                hoverText={content.moreInfoHover.hoverText}
              />
            }
            PopperProps={{
              sx: {
                '& .MuiTooltip-tooltip': {
                  maxWidth: width,
                  backgroundColor: 'transparent',
                  margin: '0 !important',
                  padding: '0',
                },
              },
            }}
            TransitionProps={{
              timeout: 0,
            }}
          >
            <button id={buttonId} data-testid={`${moreInfoTestId}-button`} className={tooltipButtonCss} type="button">
              {Parser(content.moreInfoMainTitleText)}
            </button>
          </MuiTooltip>
        </ClickAwayListener>
      </div>
    </div>
  );
};

export default Tooltip;
