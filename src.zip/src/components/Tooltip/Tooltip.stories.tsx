import React from 'react';
import { classes, content } from './TooltipData';
import Tooltip from './Tooltip';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { TooltipType } from './types';

export default {
  title: 'Miscellaneous/Tooltip',
  component: Tooltip,
} as ComponentMeta<typeof Tooltip>;

const testId = 'cmn-more-info-hover-testid';
const testDataTestId = 'cmn-more-info-hover-datatestid';

const Template: ComponentStory<typeof Tooltip> = (args: TooltipType.IProps) => {
  return <Tooltip {...args} />;
};

export const Default = Template.bind({});
Default.args = {
  id: testId,
  dataTestId: testDataTestId,
  content: content,
  classes: classes,
};
