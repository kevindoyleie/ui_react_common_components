import Styles from './tooltip.module.scss';
import { TooltipType } from './types';

const content: TooltipType.IContent = {
  moreInfoMainTitleText: `<p>More info</p>`,
  moreInfoHover: {
    hoverText: `<p>Money back on everyday medical expenses such as:</p><p>• GP visits</p><p>• Dental visits</p><p>• Physiotherapy</p><p>• Alternative Therapies</p><p>and much more.</p>`,
  },
};

const classes: TooltipType.IClasses = {
  tooltipButtonClass: `${Styles['more-info-hover__button']} test-other-class-after-button-class`,
  tooltipClass: `test-other-class-before-tooltip-class ${Styles['more-info-hover__tooltip']}`,
};

export { classes, content };
