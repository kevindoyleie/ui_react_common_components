import React from 'react';
import Parser from 'html-react-parser';
import { TooltipType } from './types';

const TooltipText = ({ moreInfoId, moreInfoTestId, tooltipClass, hoverText }: TooltipType.ITextProps): JSX.Element => {
  return (
    <div id={`${moreInfoId}-tooltip`} data-testid={`${moreInfoTestId}-tooltip`} className={tooltipClass}>
      {Parser(hoverText)}
    </div>
  );
};

export default TooltipText;
