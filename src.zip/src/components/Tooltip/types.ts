export namespace TooltipType {
  export interface IContent {
    moreInfoMainTitleText: string;
    moreInfoHover: {
      hoverText: string;
    };
  }

  export interface IClasses {
    tooltipClass?: string;
    tooltipButtonClass?: string;
    tooltipHoverClass?: string;
  }

  export interface IProps {
    id: string;
    dataTestId?: string;
    classes?: IClasses;
    content: IContent;
    width?: string;
    placement?: Placement;
  }

  export enum Placement {
    BOTTOM_END = 'bottom-end',
    BOTTOM_START = 'bottom-start',
    BOTTOM = 'bottom',
    LEFT_END = 'left-end',
    LEFT_START = 'left-start',
    LEFT = 'left',
    RIGHT_END = 'right-end',
    RIGHT_START = 'right-start',
    RIGHT = 'right',
    TOP_END = 'top-end',
    TOP_START = 'top-start',
    TOP = 'top',
  }

  export interface ITextProps {
    moreInfoId: string;
    moreInfoTestId: string;
    tooltipClass: string;
    hoverText: string;
  }
}
