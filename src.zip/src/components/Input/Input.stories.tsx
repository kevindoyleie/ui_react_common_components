import React from 'react';

import { useForm } from 'react-hook-form';

import Input from './Input';
import '../../styles/index.scss';
import { content, classes, preventNonNumerics } from './InputData';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { InputType } from './types';

export default {
  title: 'Controls/Input',
  component: Input,
  argTypes: { onChange: { action: 'changed' } },
} as ComponentMeta<typeof Input>;

const Template: ComponentStory<typeof Input> = (args: InputType.IProps) => {
  const { register } = useForm();
  return <Input {...args} register={register} />;
};

export const Default = Template.bind({});
Default.args = {
  classes,
  content,
  dataTestId: 'input-field',
};

export const NonValid = Template.bind({});
NonValid.args = {
  ...Default.args,
  errors: { [content.name]: {} },
};

export const Numeric = Template.bind({});
Numeric.args = {
  ...Default.args,
  content: { ...content, placeholder: 'Enter Age' },
  validation: {
    maxLength: 2,
    onKeyPress: preventNonNumerics,
  },
  pattern: '\\d*',
  inputMode: 'numeric',
};
