import React from 'react';
import { screen, render, within } from '@testing-library/react';
import Input from './Input';
import { register } from 'react-hook-form';
import { content, classesDefault } from './InputData';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  register: jest.fn(),
}));

describe('Testing atomic component input', () => {
  test('should have label Title ', () => {
    render(
      <Input
        dataTestId="input-field"
        classes={classesDefault}
        content={content}
        validation={{
          validator: '',
          maxLength: 2,
        }}
        register={register}
      />
    );
    const title = screen.getByText('Title');
    expect(title).toBeInTheDocument();
  });

  test('should have placeholder text Enter Title ', () => {
    render(
      <Input
        dataTestId="input-field"
        classes={classesDefault}
        content={content}
        validation={{
          validator: '',
          maxLength: 2,
        }}
        register={register}
      />
    );
    const inputNode = screen.getByPlaceholderText('Enter Title');
    expect(inputNode).toBeInTheDocument();
  });
});
