import { InputType } from './types';

const content: InputType.IContent = {
  title: 'Title',
  name: 'title',
  placeholder: 'Enter Title',
  required: true,
  errorMessage: 'Please input a valid title',
};

const classes: InputType.IClasses = {
  labelClassName: 'cmn-input-field__label',
  inputClassName: 'cmn-input-field cmn-input-field__md',
  inputErrorClassName: 'cmn-input-field__error',
  errorMessageClassName: 'cmn-input-field__error-message',
};

const preventNonNumerics: InputType.PreventNonNumericType = (evt) => {
  if (evt.keyCode < 48 || evt.keyCode > 57) {
    evt.preventDefault();
  }
};

export { content, classes, preventNonNumerics };
