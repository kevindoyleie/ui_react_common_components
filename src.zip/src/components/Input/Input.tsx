import React from 'react';
import { InputType } from './types';
import Styles from '../CustomDatePicker/input.module.scss';

/**
 * Generic input.
 *
 * Styling and content are dynamic. Input mode can be specified to display relevant virtual keyboard on mobile devices.
 */
const Input = ({
  id,
  dataTestId,
  classes = {},
  content,
  validation = {},
  register,
  errors = {},
  pattern,
  inputMode,
  onChange,
}: InputType.IProps): JSX.Element => {
  const { title, name, required, placeholder, errorMessage } = content;
  const { validator, onKeyPress, maxLength } = validation;

  const labelClassName = `${Styles['input-field__label']} ${classes.labelClassName ?? ''}`;
  const inputClassName = `${Styles['input-field']} ${Styles['input-field__sm']} ${classes.inputClassName ?? ''}`;
  const inputErrorClassName = `${Styles['input-field__error']} ${classes.inputErrorClassName ?? ''}`;
  const errorMessageClassName = `${Styles['input-field__error-message']} ${classes.errorMessageClassName ?? ''}`;

  return (
    <div data-testid={`${dataTestId}-wrap`}>
      {title && <p className={labelClassName}>{title}</p>}
      <input
        id={id}
        data-testid={dataTestId}
        className={`${inputClassName} ${errors[name] ? `${inputErrorClassName}` : ''}`}
        {...register(name, {
          required: required,
          validate: validator,
          onChange: onChange,
        })}
        placeholder={placeholder}
        onKeyPress={onKeyPress}
        maxLength={maxLength}
        pattern={pattern}
        inputMode={inputMode}
      />
      {errors[name] && (
        <p className={errorMessageClassName} data-testid="error-message">
          {errorMessage}
        </p>
      )}
    </div>
  );
};

export default Input;
