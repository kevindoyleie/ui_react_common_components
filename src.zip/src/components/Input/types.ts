import React, { ReactNode } from 'react';
import { FieldErrors, UseFormReturn } from 'react-hook-form';

export namespace InputType {
  export interface IClasses {
    labelClassName?: string;
    inputClassName?: string;
    inputErrorClassName?: string;
    errorMessageClassName?: string;
  }

  export interface IContent {
    name: string;
    title?: ReactNode;
    required?: boolean;
    placeholder: string | undefined;
    errorMessage: ReactNode;
  }

  export type PreventNonNumericType = (evt: React.KeyboardEvent<HTMLInputElement>) => void;

  export type IValidator = (value: string | number) => boolean | void;

  export interface IProps {
    id?: string | undefined;
    dataTestId: string;
    classes?: IClasses;
    content: IContent;
    validation: {
      maxLength?: number;
      validator?: any;
      onKeyPress?: PreventNonNumericType | undefined;
    };
    register: RegisterType;
    errors: FieldErrors;
    pattern?: string | undefined;
    inputMode?: 'none' | 'text' | 'tel' | 'url' | 'email' | 'numeric' | 'decimal' | 'search' | undefined;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  }

  export type RegisterType = UseFormReturn['register'];
}
