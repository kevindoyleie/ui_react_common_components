import React from 'react';
import { screen, render, within } from '@testing-library/react';
import Dropdown from './Dropdown';
import { useForm } from 'react-hook-form';
import { content, classesDefault, dataTestIds } from './DropdownData';

describe('Testing atomic component Dropdown', () => {
  function createWrapper({ isDisabled }) {
    return () => {
      const { control } = useForm();
      return (
        <Dropdown
          id="dropdown"
          dataTestIds={dataTestIds}
          classes={classesDefault}
          content={content}
          control={control}
          options={content.options}
          form="form"
          rules={{ required: true }}
          isDisabled={isDisabled}
        />
      );
    };
  }

  test('Should have label "Title"', () => {
    const DropDownWrapper = createWrapper({});
    render(<DropDownWrapper />);

    const { getByText } = within(screen.getByTestId('dropdown-wrap'));
    expect(getByText('Title')).toBeInTheDocument();
  });

  test('Should be disabled', () => {
    const DropDownWrapper = createWrapper({ isDisabled: true });
    render(<DropDownWrapper />);

    expect(screen.getByTestId('dropdown-wrap').querySelector('input')).toBeDisabled();
  });
});
