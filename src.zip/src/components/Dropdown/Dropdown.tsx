import React from 'react';
import { Controller } from 'react-hook-form';
import Select, { components, DropdownIndicatorProps, MenuListProps, MenuProps, ValueContainerProps } from 'react-select';
import Styles from './dropdown.module.scss';
import { DropdownType } from './types';

const { DropdownIndicator, Menu, MenuList, ValueContainer } = components;

/**
 * The dropdown component is used to select an option.
 * Styling and content are dynamic.
 * Customisation details in Usage.readme
 */
const Dropdown = ({
  id,
  classes = {},
  content,
  errors = {},
  control,
  form,
  options,
  rules,
  isDisabled,
  dataTestIds,
}: DropdownType.IProps): JSX.Element => {
  const labelCss = `${Styles['select-container__label']} ${classes.labelCss ?? ''}`;
  const selectErrorCss = `${Styles['select-container--error']} ${classes.selectErrorCss ?? ''}`;
  const errorMessageCss = `${Styles['select-container__error-message']} ${classes.errorMessageCss ?? ''}`;
  const selectCss = `${Styles['select-container']} ${classes.selectCss ?? ''}`;
  const classNamePrefix = classes.classNamePrefix ?? 'select';

  let title;
  if (content.title) {
    title = <p className={labelCss}>{content.title}</p>;
  }

  const {
    dataTestId,
    dropdownIndicatorDataTestId,
    menuDataTestId,
    menuListDataTestId,
    placeholderDataTestId,
    valueDataTestId,
  } = dataTestIds;

  const CustomDropdownIndicator = (props: DropdownIndicatorProps) => {
    return (
      <DropdownIndicator {...props}>
        <span data-testid={dropdownIndicatorDataTestId}>{content.dropdownIndicator}</span>
      </DropdownIndicator>
    );
  };

  const CustomMenu = (props: MenuProps) => (
    <div data-testid={menuDataTestId}>
      <Menu {...props}>{props.children}</Menu>
    </div>
  );

  const CustomMenuList = (props: MenuListProps) => (
    <div data-testid={menuListDataTestId}>
      <MenuList {...props}>{props.children}</MenuList>
    </div>
  );

  const CustomValueContainer = (props: ValueContainerProps) => (
    <span data-testid={valueDataTestId}>
      <ValueContainer {...props}>{props.children}</ValueContainer>
    </span>
  );

  return (
    <div data-testid={`${dataTestId}-wrap`}>
      {title}
      <Controller
        name={content.name}
        control={control}
        rules={rules}
        render={({ field }) => {
          return (
            <>
              <Select
                {...field}
                id={id}
                options={options}
                components={{
                  DropdownIndicator: CustomDropdownIndicator,
                  Menu: CustomMenu,
                  MenuList: CustomMenuList,
                  ValueContainer: CustomValueContainer,
                }}
                className={`${selectCss} ${errors[content.name] ? `${selectErrorCss}` : ''}`}
                classNamePrefix={classNamePrefix}
                placeholder={<span data-testid={placeholderDataTestId}>{content.placeholder}</span>}
                form={form}
                isSearchable={false}
                isDisabled={isDisabled}
              />
              {errors[content.name] && (
                <p className={errorMessageCss} data-testid={`${dataTestId}-error-message`}>
                  {content.errorMessage}
                </p>
              )}
            </>
          );
        }}
      />
    </div>
  );
};

export default Dropdown;
