import { ReactNode } from 'react';
import { FieldErrors, UseFormReturn } from 'react-hook-form';
import { RegisterOptions } from 'react-hook-form/dist/types';

export namespace DropdownType {
  export interface IClasses {
    labelCss?: string;
    selectCss?: string;
    selectErrorCss?: string;
    classNamePrefix?: string;
    errorMessageCss?: string;
  }

  export interface IContent {
    options?: IOption[];
    name: string;
    title?: ReactNode;
    placeholder?: ReactNode;
    dropdownIndicator?: ReactNode;
    errorMessage?: ReactNode;
  }

  export interface IOption {
    label: ReactNode;
    value: string;
  }

  export interface IGroup {
    label: string;
    options: IOption[];
  }

  export interface IDataTestIds {
    dataTestId: string;
    dropdownIndicatorDataTestId: string;
    placeholderDataTestId: string;
    menuDataTestId: string;
    menuListDataTestId: string;
    valueDataTestId: string;
  }

  export interface IProps {
    dataTestIds: IDataTestIds;
    id: string;
    classes?: IClasses;
    content: IContent;
    options?: IOption[];
    rules?: RegisterOptions;
    control?: ControlType;
    errors?: FieldErrors;
    form?: string;
    isDisabled: boolean;
  }

  export type ControlType = UseFormReturn['control'];
}
