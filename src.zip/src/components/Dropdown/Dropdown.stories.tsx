import React from 'react';
import { useForm } from 'react-hook-form';
import Dropdown from './Dropdown';
import { content, classesDefault, dataTestIds } from './DropdownData';
import { ComponentStory, ComponentMeta } from '@storybook/react';

export default {
  title: 'Controls/Dropdown',
  component: Dropdown,
} as ComponentMeta<typeof Dropdown>;

const Template: ComponentStory<typeof Dropdown> = (args) => {
  const { control } = useForm();
  return <Dropdown {...args} control={control} />;
};

export const Default = Template.bind({});
Default.args = {
  classes: classesDefault,
  content: { ...content, name: 'dropdown-default' },
  options: content.options,
  rules: { required: true },
  dataTestIds,
};

export const Disabled = Template.bind({});
Disabled.args = {
  ...Default.args,
  content: { ...content, name: 'dropdown-disabled' },
  isDisabled: true,
};

export const NonValid = Template.bind({});
NonValid.args = {
  ...Default.args,
  content: { ...content, name: 'dropdown-with-error' },
  errors: { ['dropdown-with-error']: {} },
};
