import Parser from 'html-react-parser';
import { DropdownType } from './types';

const content: DropdownType.IContent = {
  title: 'Title',
  name: 'name',
  placeholder: 'Please select',
  errorMessage: 'Please select option',
  dropdownIndicator: Parser(
    '<p><img src="https://aem-int.vhihealthcare.net/content/dam/vhi-spa/dropdown-icon-select-triangle.svg" alt="">&nbsp;</p>'
  ),
  options: [
    { label: 'Husband', value: 'HUSBAND' },
    { label: 'Wife', value: 'WIFE' },
    { label: 'Son', value: 'SON' },
    { label: 'Daughter', value: 'DAUGHTER' },
    { label: 'Partner (male)', value: 'MALE_PARTNER' },
    { label: 'Partner (female)', value: 'FEMALE_PARTNER' },
    { label: 'Other (male)', value: 'OTHER_MALE' },
    { label: 'Other (female)', value: 'OTHER_FEMALE' },
  ],
};

const classesDefault: DropdownType.IClasses = {};

const dataTestIds: DropdownType.IDataTestIds = {
  dataTestId: 'dropdown',
  dropdownIndicatorDataTestId: 'dropdown-indicator',
  placeholderDataTestId: 'dropdown-placeholder',
  menuDataTestId: 'dropdown-menu',
  menuListDataTestId: 'dropdown-menu-list',
  valueDataTestId: 'dropdown-value',
};

export { content, classesDefault, dataTestIds };
