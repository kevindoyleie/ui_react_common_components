import React from 'react';
import { screen, render } from '@testing-library/react';
import DataProtection from './DataProtection';
import dataProtectionContent from './DataProtectionData';

describe('feature Footer DataProtection', () => {
  test('DataProtection should always render', () => {
    render(<DataProtection dataProtectionContent={dataProtectionContent} />);

    expect(screen.getByTestId('cmn-data-protection')).toBeInTheDocument();
    expect(screen.getByTestId('cmn-data-protection').querySelector('p')).toHaveTextContent(
      `Find out more about Vhi's Data Protection Policy and why we are collecting your data`
    );
    expect(screen.getByTestId('cmn-data-protection').querySelector('p > a')).toHaveAttribute(
      'href',
      'https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/privacy-policy.html'
    );
  });
});
