export namespace DataProtectionType {
  export interface IContent {
    dataProtectionText: string;
  }

  export interface IProps {
    dataProtectionContent: IContent;
  }
}
