import React from 'react';
import Parser from 'html-react-parser';
import Styles from './dataProtection.module.scss';
import { DataProtectionType } from './types';

/**
 * The data protection component.
 *
 * Content is dynamic.
 */
function DataProtection({ dataProtectionContent }: DataProtectionType.IProps): JSX.Element {
  return (
    <div className={Styles['data-protection']} data-testid="cmn-data-protection">
      {Parser(dataProtectionContent.dataProtectionText)}
    </div>
  );
}

export default DataProtection;
