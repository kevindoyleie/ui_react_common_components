import { DataProtectionType } from './types';

const dataProtectionContent: DataProtectionType.IContent = {
  dataProtectionText:
    "<p>Find out more about&nbsp;<a href='https://vmsys166.vhihealthcare.net/content/vhigroupservices/language-master/en/privacy-policy.html'>Vhi's Data Protection Policy</a>&nbsp;and why we are collecting your data</p>",
};

export default dataProtectionContent;
