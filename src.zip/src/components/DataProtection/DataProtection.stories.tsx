import React from 'react';
import DataProtection from './DataProtection';
import dataProtectionContent from './DataProtectionData';
import { ComponentStory, ComponentMeta } from '@storybook/react';

export default {
  title: 'Security/DataProtection',
  component: DataProtection,
} as ComponentMeta<typeof DataProtection>;

const Template: ComponentStory<typeof DataProtection> = (args) => <DataProtection {...args} />;

export const Default = Template.bind({});
Default.args = {
  dataProtectionContent,
};
