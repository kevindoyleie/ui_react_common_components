import { HeroBannerType } from './types';

const heroBannerContent: HeroBannerType.IContent = {
  AEM_SERVER_PREFIX: 'https://vmsys166.vhihealthcare.net',
  srcUriTemplate:
    '/content/vhi-spa/find-a-plan/_jcr_content/main-content/image.coreimg.100{.width}.jpeg/1650537802655/hero-find-plan.jpeg',
  widths: [320, 768, 1024],
  titleLg: '<p>Find a Plan</p>',
  titleSm: '<p>When you need us, we’re there</p>',
  array: ['hero-find-plan320.jpeg', 'hero-find-plan768.jpeg', 'hero-find-plan1024.jpeg'],
};

export default heroBannerContent;
