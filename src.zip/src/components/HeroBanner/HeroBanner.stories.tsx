import React from 'react';
import HeroBanner from './HeroBanner';
import heroBannerContent from './HeroBannerData';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import { HeroBannerType } from './types';

export default {
  title: 'Layout/HeroBanner',
  component: HeroBanner,
} as ComponentMeta<typeof HeroBanner>;

const Template: ComponentStory<typeof HeroBanner> = (args: HeroBannerType.IProps) => <HeroBanner {...args} />;

export const Default = Template.bind({});
Default.args = {
  heroBannerContent,
};
