import React from 'react';
import { HeroBannerType } from './types';

function ResponsiveHeroImage({ imageArray }: HeroBannerType.IResponsiveImageProps): JSX.Element {
  return (
    <picture data-testid="cmn-responsive-hero-img" id="cmn-responsive-hero-img" className="cmn-responsive-hero-img">
      <source media="(min-width: 1024px)" srcSet={`${imageArray[2]} 1023w`} data-testid="cmn-responsive-hero-img-lg" />
      <source media="(min-width: 768px)" srcSet={`${imageArray[1]} 767w`} data-testid="cmn-responsive-hero-img-md" />
      <img srcSet={`${imageArray[0]} 320w`} alt="hero-img" />
    </picture>
  );
}

export default ResponsiveHeroImage;
