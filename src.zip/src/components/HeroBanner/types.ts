export namespace HeroBannerType {
  export interface IContent {
    widths: number[];
    AEM_SERVER_PREFIX: string;
    srcUriTemplate: string;
    titleLg: string;
    titleSm: string;
    array?: string[];
  }

  export interface IProps {
    heroBannerContent: IContent;
  }

  export interface IResponsiveImageProps {
    imageArray: string[];
  }
}
