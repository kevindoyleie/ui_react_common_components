import React from 'react';
import { screen, render, within } from '@testing-library/react';
import HeroBanner from './HeroBanner';
import heroBannerContent from './HeroBannerData';

describe('Test feature Hero Banner', () => {
  test('Hero banner exists', () => {
    render(<HeroBanner heroBannerContent={heroBannerContent} />);
    const heroBanner = screen.getByTestId('hero-banner');
    expect(heroBanner).toBeInTheDocument();
  });

  test('Hero large text', () => {
    render(<HeroBanner heroBannerContent={heroBannerContent} />);
    const { getByText } = within(screen.getByTestId('hero-banner'));
    expect(getByText('Find a Plan')).toBeInTheDocument();
  });

  test('Hero small text', () => {
    render(<HeroBanner heroBannerContent={heroBannerContent} />);
    const { getByText } = within(screen.getByTestId('hero-banner'));
    expect(getByText('When you need us, we’re there')).toBeInTheDocument();
  });
});
