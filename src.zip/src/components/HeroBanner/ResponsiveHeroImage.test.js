import React from 'react';
import { screen, render } from '@testing-library/react';
import ResponsiveHeroImage from './ResponsiveHeroImage';
import heroBannerContent from './HeroBannerData';

describe('Test feature Responsive Image', () => {
  test('Responsive Image exists', () => {
    render(<ResponsiveHeroImage imageArray={heroBannerContent.array} />);
    const heroImg = screen.getByTestId('cmn-responsive-hero-img');
    expect(heroImg).toBeInTheDocument();
  });

  test('Img must have correct defaul img and alt tag', () => {
    render(<ResponsiveHeroImage imageArray={heroBannerContent.array} />);
    const heroImg = screen.getByRole('img');
    expect(heroImg).toHaveAttribute('srcset', 'hero-find-plan320.jpeg 320w');
    expect(heroImg).toHaveAttribute('alt', 'hero-img');
  });

  test('Other images are present', () => {
    render(<ResponsiveHeroImage imageArray={heroBannerContent.array} />);
    const md = screen.getByTestId('cmn-responsive-hero-img-md');
    const lg = screen.getByTestId('cmn-responsive-hero-img-lg');
    expect(md).toBeInTheDocument();
    expect(lg).toBeInTheDocument();
  });
});
