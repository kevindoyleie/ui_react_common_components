import React from 'react';
import Parser from 'html-react-parser';
import ResponsiveHeroImage from './ResponsiveHeroImage';
import Styles from './heroBanner.module.scss';
import { HeroBannerType } from './types';

const createImageArray = (
  AEM_SERVER_PREFIX: string,
  srcUriTemplate: string,
  mobile: number,
  tablet: number,
  desktop: number
) => {
  const smallImage = AEM_SERVER_PREFIX + srcUriTemplate.replace('{.width}', '.' + mobile);
  const mediumImage = AEM_SERVER_PREFIX + srcUriTemplate.replace('{.width}', '.' + tablet);
  const largeImage = AEM_SERVER_PREFIX + srcUriTemplate.replace('{.width}', '.' + desktop);
  const imageArray = [smallImage, mediumImage, largeImage];
  return imageArray;
};

/**
 * Responsive hero banner component.
 *
 * Content and images is dynamic.
 */
function HeroBanner({ heroBannerContent }: HeroBannerType.IProps): JSX.Element {
  const [mobile, tablet, desktop] = heroBannerContent.widths;

  const imageArray = createImageArray(
    heroBannerContent.AEM_SERVER_PREFIX,
    heroBannerContent.srcUriTemplate,
    mobile,
    tablet,
    desktop
  );

  return (
    <div data-testid="hero-banner" className={Styles['hero-banner__hero-wrapper']}>
      <div className={Styles['hero-banner__hero-wrapper__img-container']}>
        <ResponsiveHeroImage imageArray={imageArray} />
      </div>
      <div data-testid="hero-banner-text" className={`${Styles['hero-banner__hero-wrapper__text-hdr']} flex-md-row`}>
        <div
          id="cmn-hero-banner__hero-wrapper__text-hdr__text-l"
          className={Styles['hero-banner__hero-wrapper__text-hdr__text-l']}
        >
          {Parser(heroBannerContent.titleLg)}
        </div>
        <div
          id="cmn-hero-banner__hero-wrapper__text-hdr__text-s"
          className={Styles['hero-banner__hero-wrapper__text-hdr__text-s']}
        >
          {Parser(heroBannerContent.titleSm)}
        </div>
      </div>
    </div>
  );
}

export default HeroBanner;
