import { createTheme } from '@mui/material/styles';

declare module '@mui/material/styles/createPalette' {
  interface Palette {
    customGrey: {
      black: string;
      dark: string;
      darkest: string;
      light: string;
      lightest: string;
      white: string;
    };
  }
  interface PaletteOptions {
    customGrey?: {
      black: string;
      dark: string;
      darkest: string;
      light: string;
      lightest: string;
      white: string;
    };
  }
}

export const muiTheme = createTheme({
  palette: {
    primary: {
      main: '#e17000',
      light: '#f6a42d',
      dark: '#a84201',
    },
    secondary: {
      main: '#993eaa',
      light: '#d582e1',
      dark: '#6e267b',
    },
    customGrey: {
      black: '#202020',
      dark: '#9b9b9b',
      darkest: '#696969',
      light: '#cfcfcf',
      lightest: 'string',
      white: '#ffffff',
    },
  },
  typography: {
    fontFamily: 'Open Sans',
    button: {
      textTransform: 'none',
    },
  },
});
