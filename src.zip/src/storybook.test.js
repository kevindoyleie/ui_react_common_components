import initStoryshots from '@storybook/addon-storyshots';
import { createSerializer } from '@emotion/jest';
initStoryshots({
  snapshotSerializers: [createSerializer()],
});
