import DatePicker from 'react-datepicker';
import { Controller } from 'react-hook-form';
import PropTypes from 'prop-types'; 
import Parser from 'html-react-parser';
import BootstrapTooltip from '../BootstrapTooltip/BootstrapTooltip';

/**
 * The custom date picker component is used to select a date from calendar.
 *
 *  Styling and content are dynamic. Min and max start dates are configurable.
 */
const CustomDatePicker = ({
  id,
  dataTestId,
  classes = {},
  content,
  control,
  minStartDate,
  maxStartDate,
  errors = {},
}) => {
  let title;
  if (content.title) {
    title = <p className={classes.labelClassName}>{content.title}</p>;
  }

  let tooltip;
  if (content.policyStartDateInfoText) {
    tooltip = (
      <span className="cmn-input__date-picker-tooltip">
        <BootstrapTooltip
          id={`date-picker-start-date`}
          content={{
            moreInfoHover: {
              hoverText: content.policyStartDateInfoText,
            },
            moreInfoMainTitleText: content.policyStartDateInfoIcon,
          }}
          classes={{
            tooltipClass: 'cmn-more-info-hover__tooltip',
            tooltipButtonClass: 'cmn-more-info-hover__button p-0',
          }}
        />
      </span>
    );
  }

  return (
    <div data-testid={`${dataTestId}-wrap`} className="cmn-input-wrap">
      <span className="cmn-input__label-wrap">
        {title}
        {tooltip}
      </span>
      <div className={classes.calendarImageClassName}>
        {Parser(content.imageContent)}
      </div>
      <Controller
        type="date"
        control={control}
        name={content.name}
        render={({ field }) => (
          <DatePicker
            id={id || null}
            className={classes.inputClassName}
            selected={field.value ? field.value : new Date().getTime()}
            onChange={(val) => field.onChange(val)}
            minDate={minStartDate}
            maxDate={maxStartDate}
            placeholderText={content.placeholder}
            dateFormat="dd/MM/yyyy"
            formatWeekDay={(nameOfDay) => nameOfDay.substr(0, 1)}
            showMonthDropdown
            showYearDropdown
            dropdownMode="select"
          />
        )}
      />
      {errors[content.name] && (
        <p className={classes.errorMessageClassName}>{content.errorMessage}</p>
      )}
    </div>
  );
};

export default CustomDatePicker;

CustomDatePicker.propTypes = {
  id: PropTypes. PropTypes.string,
  dataTestId: PropTypes.string.isRequired,
  classes: PropTypes.shape({
    labelClassName: PropTypes.string,
    calendarImageClassName: PropTypes.string,
    inputClassName: PropTypes.string,
    errorMessageClassName: PropTypes.string,
  }),
  control: PropTypes.object.isRequired,
  minStartDate: PropTypes.number.isRequired, 
  maxStartDate: PropTypes.number.isRequired,
  errors: PropTypes.object
};
